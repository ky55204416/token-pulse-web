#!/bin/zsh
cd -- "${0:A:h}" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:${PATH}"
if ! command -v node >/dev/null; then
  printf '%s\n' '需要 Node.js 22.15 或更新版本。'
  exit 1
fi
exec node app/server.mjs --open
