import { randomBytes, timingSafeEqual } from 'node:crypto';

const webUrl = 'https://ky55204416.github.io/token-pulse-web/';
const webOrigin = new URL(webUrl).origin;
const tokenLifetimeMs = 8 * 60 * 60 * 1000;
const consentPage = `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>连接网页版 · 智脉</title>
    <link rel="icon" href="/pulse-icon.png">
    <link rel="stylesheet" href="/styles.css">
  </head>
  <body>
    <main class="shell">
      <section class="panel" aria-labelledby="connect-heading">
        <h1 id="connect-heading">连接智脉网页版</h1>
        <p>连接后，网页版可以刷新并读取本机最近 30 天的用量汇总，包括渠道、模型和 Token 统计。对话内容、项目名称和文件路径保留在本机。</p>
        <p>授权适用于本次打开的 GitHub Pages 页面，最长 8 小时。本机版退出后授权自动失效。</p>
        <form action="/connect-web" method="post">
          <button class="button" type="submit">允许并打开网页版</button>
        </form>
      </section>
    </main>
  </body>
</html>`;

function reasoning({ reasoningEfforts, reasoningSettings, reasoningSettingsSupported }) {
  return {
    reasoningEfforts: reasoningEfforts.map(({ effort, total }) => ({ effort, total })),
    reasoningSettings: reasoningSettings.map(({ setting, sessions }) => ({ setting, sessions })),
    reasoningSettingsSupported,
  };
}

function summarize(dashboard, generatedAt) {
  const { total, input, cached, output, splitInput, splitOutput, splitCached,
    knownSplitTotal, measuredTotal, estimatedTotal, sessions, activeDays } = dashboard.totals;
  return {
    title: '我的算力看板摘要',
    range: { from: dashboard.from, to: dashboard.to },
    generatedAt,
    totals: { total, input, cached, output, splitInput, splitOutput, splitCached,
      knownSplitTotal, measuredTotal, estimatedTotal, sessions, activeDays },
    focus: null,
    sources: dashboard.sources.map(row => {
      const { id, name, quality, total, input, cached, output, sessions, activeDays, coverageFrom, coverageTo } = row;
      return { id, name, quality, total, input, cached, output, sessions, activeDays, coverageFrom, coverageTo,
        ...reasoning(row) };
    }),
    daily: dashboard.daily.map(({ date, total, codex, claude, workbuddy }) => ({ date, total, codex, claude, workbuddy })),
    reasoningEfforts: dashboard.reasoningEfforts.map(({ effort, total }) => ({ effort, total })),
    models: dashboard.models
      .filter(({ name }) => name.trim() && name.length <= 256 && !/^(?:[/\\]|[a-z]:[\\/]|file:)/i.test(name))
      .slice(0, 500)
      .map(row => {
        const { source, name, total, sessions } = row;
        return { source, name, total, sessions, ...reasoning(row) };
      }),
  };
}

export function createWebConnection({ port, commonHeaders, reply, startRefresh, getUsage }) {
  const enabled = port === 4317;
  const consentHeaders = {
    ...commonHeaders,
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Security-Policy': commonHeaders['Content-Security-Policy']
      .replace("form-action 'none'", "form-action 'self' " + webUrl),
    'Referrer-Policy': 'same-origin',
    'X-Frame-Options': 'DENY',
  };
  const usageHeaders = {
    ...commonHeaders,
    'Access-Control-Allow-Origin': webOrigin,
    'Vary': 'Origin',
    'Content-Type': 'application/json; charset=utf-8',
  };
  let authorization;

  function isAuthorized(header) {
    const match = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(header || '');
    return Boolean(match && authorization && Date.now() < authorization.expiresAt
      && timingSafeEqual(Buffer.from(match[1]), authorization.value));
  }

  return function handleWebConnection(request, response, { pathname }) {
    const { method, headers } = request;
    if (pathname === '/connect-web') {
      if (!enabled) {
        reply(response, 409, { error: '连接网页版需要使用默认端口 4317。' });
      } else if (method === 'GET' && (!headers['sec-fetch-dest'] || headers['sec-fetch-dest'] === 'document')) {
        response.writeHead(200, consentHeaders).end(consentPage);
      } else if (method === 'POST' && headers.origin === 'http://' + headers.host
          && (!headers['sec-fetch-site'] || headers['sec-fetch-site'] === 'same-origin')
          && (!headers['sec-fetch-dest'] || headers['sec-fetch-dest'] === 'document')) {
        const token = randomBytes(32).toString('base64url');
        authorization = { value: Buffer.from(token), expiresAt: Date.now() + tokenLifetimeMs };
        response.writeHead(303, { ...consentHeaders, Location: webUrl + '#connect=' + token }).end();
      } else {
        reply(response, 403, { error: '请从本机页面确认连接。' });
      }
      return true;
    }
    if (pathname !== '/connect-web/usage') return false;
    if (!enabled || headers.origin !== webOrigin) {
      reply(response, 403, { error: '此接口仅供已授权的智脉网页版访问。' });
    } else if (method === 'OPTIONS') {
      response.writeHead(204, {
        ...usageHeaders,
        'Access-Control-Allow-Headers': 'Authorization',
        'Access-Control-Allow-Methods': 'GET, POST',
      }).end();
    } else if (!isAuthorized(headers.authorization)) {
      response.writeHead(401, usageHeaders).end(JSON.stringify({ error: '连接授权已失效，请重新连接本机版。' }));
    } else if (method === 'POST') {
      void startRefresh();
      response.writeHead(202, usageHeaders).end(JSON.stringify({ refreshing: true }));
    } else if (method === 'GET') {
      const { refreshing, generatedAt, dashboard } = getUsage();
      const summary = dashboard ? summarize(dashboard, generatedAt) : null;
      response.writeHead(200, usageHeaders).end(JSON.stringify({ refreshing, summary }));
    } else {
      response.writeHead(405, { ...usageHeaders, Allow: 'GET, POST, OPTIONS' }).end();
    }
    return true;
  };
}
