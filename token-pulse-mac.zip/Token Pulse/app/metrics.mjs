import { createHash } from 'node:crypto';

const timeZone = 'Asia/Singapore';
const dayFormat = new Intl.DateTimeFormat('sv-SE', { timeZone, dateStyle: 'short' });
const dayMs = 86400000;
const effortLevels = ['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'ultra', 'max'];
const reasoningSettings = [...effortLevels, 'enabled', 'disabled'];

export function normalizeReasoningEffort(value) {
  if (typeof value !== 'string') return null;
  const level = value.trim().toLowerCase();
  return effortLevels.includes(level) ? level : null;
}

export function normalizeReasoningSetting(value) {
  if (typeof value !== 'string') return null;
  const setting = value.trim().toLowerCase();
  return reasoningSettings.includes(setting) ? setting : null;
}

function addEffort(totals, level, total) {
  if (level && total > 0) totals.set(level, (totals.get(level) ?? 0) + total);
}

function addReasoningSetting(settings, setting, sessionKey) {
  if (!setting || !sessionKey) return;
  const sessions = settings.get(setting) ?? new Set();
  sessions.add(sessionKey);
  settings.set(setting, sessions);
}

function formatReasoningSettings(settings) {
  return reasoningSettings.filter(setting => settings.has(setting))
    .map(setting => ({ setting, sessions: settings.get(setting).size }));
}

function formatEfforts(totals) {
  return effortLevels.filter(effort => totals.has(effort))
    .map(effort => ({ effort, total: totals.get(effort) }));
}

function addModel(models, source, row, level, setting, reasoningSettingsSupported) {
  const name = row.model || '未知模型';
  const key = source + '\0' + name;
  const model = models.get(key) ?? {
    source, name, total: 0, effortTotals: new Map(), settings: new Map(), sessionKeys: new Set(),
    ...(reasoningSettingsSupported ? { reasoningSettingsSupported } : {}),
  };
  model.total += row.total;
  addEffort(model.effortTotals, level, row.total);
  addReasoningSetting(model.settings, setting, row.sessionKey);
  if (row.sessionKey) model.sessionKeys.add(row.sessionKey);
  models.set(key, model);
}

function formatModels(models) {
  return Array.from(models.values()).filter(model => model.total > 0)
    .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name))
    .map(({ effortTotals, settings, sessionKeys, ...model }) => ({
      ...model,
      sessions: sessionKeys.size,
      reasoningEfforts: formatEfforts(effortTotals),
      reasoningSettings: formatReasoningSettings(settings),
    }));
}

export const sources = [
  { id: 'codex', name: 'Codex' },
  { id: 'claude', name: 'Claude Code' },
  { id: 'workbuddy', name: 'Workbuddy' },
];
const toolCatalog = [
  ...sources,
  { id: 'antigravity', name: '反重力 IDE' },
  { id: 'trae', name: 'Trae' },
  { id: 'codearts', name: '华为码道云' },
  { id: 'lingma', name: '通义灵码' },
  { id: 'copilot', name: 'GitHub Copilot' },
  { id: 'cursor', name: 'Cursor' },
  { id: 'windsurf', name: 'Windsurf' },
  { id: 'cline', name: 'Cline' },
  { id: 'roo', name: 'Roo Code' },
  { id: 'continue', name: 'Continue' },
  { id: 'aider', name: 'Aider' },
  { id: 'kiro', name: 'Kiro' },
  { id: 'qoder', name: 'Qoder' },
];

function sourceNote(id, state) {
  if (state === 'stale') return '显示上次更新的用量';
  if (state === 'unavailable') return '暂无可用的本机用量';
  if (state !== 'ready') return '正在读取本机用量';
  return id === 'workbuddy' ? '会话累计用量' : '本机会话用量';
}

export function dayOf(value) {
  return dayFormat.format(value);
}

function dateOffset(date, offset) {
  return new Date(Date.parse(date + 'T00:00:00Z') + offset * dayMs).toISOString().slice(0, 10);
}

function blankTotals() {
  return {
    total: 0, input: null, cached: null, output: null, knownSplitTotal: 0,
    splitInput: null, splitOutput: null, splitCached: null,
    measuredTotal: 0, estimatedTotal: 0,
    sessionKeys: new Set(), days: new Set(),
  };
}

function add(totals, row, source) {
  totals.total += row.total;
  totals[row.estimated ? 'estimatedTotal' : 'measuredTotal'] += row.total;
  if (row.sessionKey) totals.sessionKeys.add(source + ':' + row.sessionKey);
  if (row.total > 0) totals.days.add(row.date);
  for (const field of ['input', 'cached', 'output']) {
    if (Number.isFinite(row[field])) totals[field] = (totals[field] ?? 0) + row[field];
  }
  if (Number.isFinite(row.input) && Number.isFinite(row.output)) {
    totals.knownSplitTotal += row.total;
    totals.splitInput = (totals.splitInput ?? 0) + row.input;
    totals.splitOutput = (totals.splitOutput ?? 0) + row.output;
    if (Number.isFinite(row.cached)) totals.splitCached = (totals.splitCached ?? 0) + row.cached;
  }
}

function formatTotals({ sessionKeys, days, ...totals }) {
  return { ...totals, sessions: sessionKeys.size, activeDays: days.size };
}

export function buildDashboard(groups, { range = '30', focus = null, today = dayOf(new Date()) } = {}) {
  const to = today;
  let earliest = today;
  let lifetimeTotal = 0;
  for (const { rows } of Object.values(groups)) {
    for (const { date, total } of rows) {
      if (date < earliest) earliest = date;
      if (date <= to) lifetimeTotal += total;
    }
  }
  const from = range === 'all' ? earliest : dateOffset(to, 1 - Number(range));
  const modelTotals = new Map();
  const effortTotals = new Map();
  const totals = blankTotals();
  const byDate = new Map();
  const sessionMap = new Map();
  const byHour = new Map();
  const hourlySources = new Set();
  let hourlyTotal = 0;
  const bySource = sources.map(source => {
    const { id, name } = source;
    const group = groups[id];
    const reasoningSettingsSupported = group?.status?.reasoningSettingsSupported === true;
    const subtotal = blankTotals();
    const sourceEfforts = new Map();
    const sourceSettings = new Map();
    let coverageFrom = null;
    let coverageTo = null;
    for (const row of group?.rows ?? []) {
      if (coverageFrom === null || row.date < coverageFrom) coverageFrom = row.date;
      if (coverageTo === null || row.date > coverageTo) coverageTo = row.date;
      if (row.date < from || row.date > to) continue;
      add(subtotal, row, id);
      const level = normalizeReasoningEffort(row.reasoningEffort);
      const setting = normalizeReasoningSetting(row.reasoningSetting);
      addEffort(sourceEfforts, level, row.total);
      addReasoningSetting(sourceSettings, setting, row.sessionKey);
      const day = byDate.get(row.date) ?? {};
      day[id] = (day[id] ?? 0) + row.total;
      byDate.set(row.date, day);
      if (focus && focus !== id) continue;
      add(totals, row, id);
      addEffort(effortTotals, level, row.total);
      addModel(modelTotals, id, row, level, setting, reasoningSettingsSupported);
      if (row.sessionKey) {
        const modelName = row.model || '未知模型';
        const sessionKey = id + ':' + row.sessionKey;
        const session = sessionMap.get(sessionKey) ?? {
          project: null,
          source: id, firstDate: row.date, lastDate: row.date, model: modelName,
          total: 0, input: null, output: null, estimated: false,
          effortTotals: new Map(),
        };
        if (row.date < session.firstDate) session.firstDate = row.date;
        if (row.date >= session.lastDate) {
          session.lastDate = row.date;
          session.model = modelName;
          session.reasoningSetting = setting;
          if (row.project) session.project = row.project;
        }
        if (!session.project && row.project) session.project = row.project;
        session.total += row.total;
        addEffort(session.effortTotals, level, row.total);
        session.estimated ||= row.estimated === true;
        for (const field of ['input', 'output']) {
          if (Number.isFinite(row[field])) session[field] = (session[field] ?? 0) + row[field];
        }
        sessionMap.set(sessionKey, session);
      }
      if (Number.isInteger(row.hour) && row.hour >= 0 && row.hour < 24) {
        hourlySources.add(id);
        hourlyTotal += row.total;
        const hour = byHour.get(row.hour) ?? { total: 0, sessionKeys: new Set() };
        hour.total += row.total;
        if (row.sessionKey) hour.sessionKeys.add(id + ':' + row.sessionKey);
        byHour.set(row.hour, hour);
      }
    }
    const state = group?.state ?? 'pending';
    return {
      id, name,
      state,
      quality: group?.status.quality ?? 'unavailable',
      note: sourceNote(id, state),
      coverageFrom, coverageTo,
      ...formatTotals(subtotal),
      reasoningEfforts: formatEfforts(sourceEfforts),
      reasoningSettings: formatReasoningSettings(sourceSettings),
      ...(reasoningSettingsSupported ? { reasoningSettingsSupported } : {}),
    };
  });
  const daily = [];
  for (let date = from; date <= to; date = dateOffset(date, 1)) {
    const values = byDate.get(date) ?? {};
    const day = { date, total: null };
    for (const source of bySource) {
      if (focus && source.id !== focus) {
        day[source.id] = null;
        continue;
      }
      const onRecord = source.coverageFrom !== null && date >= source.coverageFrom && date <= source.coverageTo;
      day[source.id] = values[source.id] ?? (onRecord ? 0 : null);
      if (day[source.id] !== null) day.total = (day.total ?? 0) + day[source.id];
    }
    daily.push(day);
  }
  return {
    from, to, totals: formatTotals(totals), daily, sources: bySource,
    toolCatalog, lifetimeTotal,
    focus,
    reasoningEfforts: formatEfforts(effortTotals),
    hourlySources: [...hourlySources], hourlyTotal,
    hourly: byHour.size === 0 ? [] : Array.from({ length: 24 }, (_, hour) => ({
      hour, total: byHour.get(hour)?.total ?? 0, sessions: byHour.get(hour)?.sessionKeys.size ?? 0,
    })),
    sessions: Array.from(sessionMap.values()).sort((a, b) => b.lastDate.localeCompare(a.lastDate)
      || b.total - a.total || (a.project ?? '').localeCompare(b.project ?? '', 'zh-CN')).slice(0, 100)
      .map(({ effortTotals, ...session }) => ({ ...session, reasoningEfforts: formatEfforts(effortTotals) })),
    models: formatModels(modelTotals),
  };
}

export function buildLightBackup(groups, { generatedAt = null, today = dayOf(new Date()) } = {}) {
  const projects = new Map();
  let from = null;
  let to = null;
  for (const { id } of sources) {
    const group = groups[id];
    const settingsSupported = group?.status?.reasoningSettingsSupported === true;
    for (const row of group?.rows ?? []) {
      if (row.total <= 0 || row.date > today) continue;
      const projectName = typeof row.project === 'string' ? row.project.trim() || null : null;
      const project = projects.get(projectName) ?? {
        name: projectName || '未记录项目', total: 0, from: row.date, to: row.date,
        sessionKeys: new Set(), models: new Map(),
      };
      project.total += row.total;
      if (row.date < project.from) project.from = row.date;
      if (row.date > project.to) project.to = row.date;
      if (!from || row.date < from) from = row.date;
      if (!to || row.date > to) to = row.date;
      if (row.sessionKey) project.sessionKeys.add(id + ':' + row.sessionKey);
      addModel(project.models, id, row, normalizeReasoningEffort(row.reasoningEffort),
        normalizeReasoningSetting(row.reasoningSetting), settingsSupported);
      projects.set(projectName, project);
    }
  }
  return {
    from, to, generatedAt,
    projects: Array.from(projects, ([key, { sessionKeys, models, ...project }]) => ({
      ...project,
      id: createHash('sha256').update(JSON.stringify(key)).digest('hex').slice(0, 24),
      sessions: sessionKeys.size,
      models: formatModels(models),
    })).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'zh-CN')),
  };
}
