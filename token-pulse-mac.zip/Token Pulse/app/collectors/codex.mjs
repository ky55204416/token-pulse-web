import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, readFile, readdir, rename, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { createZstdDecompress } from 'node:zlib';
import { normalizeReasoningEffort } from '../metrics.mjs';

const CACHE_VERSION = 3;
const DATE_FORMAT = new Intl.DateTimeFormat('sv-SE', {
  timeZone: 'Asia/Singapore',
  dateStyle: 'short',
});
const HOUR_FORMAT = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Singapore',
  hour: '2-digit',
  hourCycle: 'h23',
});
const MAX_LINE_LENGTH = 8 * 1024 * 1024;

function digest(value) {
  return createHash('sha256').update(value).digest('hex').slice(0, 24);
}

function tokenNumber(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

function projectNameFromPath(value) {
  if (typeof value !== 'string' || !value) return null;
  const trimmed = value.replace(/[\\/]+$/, '');
  const name = path.basename(trimmed);
  if (!name || name === '.' || name === path.sep) return null;
  return name.slice(0, 160);
}

function usageRow({ timestamp, responseId, sessionId, model, usage, estimated }) {
  const input = tokenNumber(usage?.input_tokens);
  const output = tokenNumber(usage?.output_tokens);
  const total = tokenNumber(usage?.total_tokens);
  if (input === null || output === null || total === null || total !== input + output) return null;

  const date = new Date(timestamp);
  if (!Number.isFinite(date.getTime())) return null;

  return {
    date: DATE_FORMAT.format(date),
    hour: Number(HOUR_FORMAT.format(date)),
    sessionKey: digest(sessionId || responseId || String(timestamp) + ':' + String(total)),
    responseKey: responseId ? digest(responseId) : null,
    model: typeof model === 'string' && model ? model : '未标注模型',
    input,
    cached: tokenNumber(usage?.cached_input_tokens),
    output,
    total,
    estimated: Boolean(estimated),
  };
}

async function walkLogs(directory, rootDirectory, scope, homeKey, files) {
  let entries;
  try {
    entries = await readdir(directory, { withFileTypes: true });
  } catch (error) {
    if (error.code === 'ENOENT') return;
    throw error;
  }

  for (const entry of entries) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await walkLogs(file, rootDirectory, scope, homeKey, files);
      continue;
    }
    if (!entry.isFile() || !/\.jsonl(?:\.zst)?$/.test(entry.name)) continue;
    const relative = path.relative(rootDirectory, file);
    const normalized = path.basename(relative).replace(/\.zst$/, '');
    const info = await stat(file);
    files.push({
      file,
      cacheKey: digest(homeKey + ':' + normalized),
      selectionKey: homeKey + ':' + normalized,
      priority: (scope === 'sessions' ? 2 : 0) + (file.endsWith('.zst') ? 0 : 1),
      isZstd: file.endsWith('.zst'),
      size: info.size,
      mtimeMs: Math.trunc(info.mtimeMs),
    });
  }
}

async function discoverLogs() {
  const configured = process.env.CODEX_HOME || path.join(os.homedir(), '.codex');
  const homes = configured.split(',').map(value => value.trim()).filter(Boolean);
  const candidates = [];
  for (const home of homes) {
    const homeKey = digest(home);
    const active = path.join(home, 'sessions');
    const archived = path.join(home, 'archived_sessions');
    await walkLogs(active, active, 'sessions', homeKey, candidates);
    await walkLogs(archived, archived, 'archived_sessions', homeKey, candidates);
  }
  const selected = new Map();
  for (const candidate of candidates) {
    const prior = selected.get(candidate.selectionKey);
    if (!prior || candidate.priority > prior.priority) selected.set(candidate.selectionKey, candidate);
  }
  return [...selected.values()];
}

async function readCache(cacheFile) {
  try {
    const parsed = JSON.parse(await readFile(cacheFile, 'utf8'));
    if (parsed.version === CACHE_VERSION && parsed.files && typeof parsed.files === 'object') return parsed;
  } catch {}
  return { version: CACHE_VERSION, files: {} };
}

async function saveCache(cacheFile, cache) {
  await mkdir(path.dirname(cacheFile), { recursive: true });
  const temporary = cacheFile + '.' + String(process.pid) + '.tmp';
  await writeFile(temporary, JSON.stringify(cache), { encoding: 'utf8', mode: 0o600 });
  await rename(temporary, cacheFile);
}

async function* linesFromFile(file, isZstd) {
  const input = createReadStream(file, { highWaterMark: 1024 * 1024 });
  const stream = isZstd ? input.pipe(createZstdDecompress()) : input;
  if (stream !== input) input.on('error', error => stream.destroy(error));
  const decoder = new StringDecoder('utf8');
  let pending = '';
  let discarding = false;
  for await (const chunk of stream) {
    pending += decoder.write(chunk);
    let newline;
    while ((newline = pending.indexOf('\n')) !== -1) {
      const line = pending.slice(0, newline);
      pending = pending.slice(newline + 1);
      if (discarding) {
        discarding = false;
        continue;
      }
      yield line;
    }
    if (pending.length > MAX_LINE_LENGTH) {
      pending = '';
      discarding = true;
    }
  }
  pending += decoder.end();
  if (!discarding && pending) yield pending;
}

async function readProject(file) {
  for await (const line of linesFromFile(file.file, file.isZstd)) {
    if (!line.includes('session_meta')) continue;
    try {
      const record = JSON.parse(line);
      if (record.type !== 'session_meta') continue;
      const payload = record.payload || {};
      const root = typeof payload.cwd === 'string'
        ? payload.cwd
        : payload.runtime_workspace_roots?.find(value => typeof value === 'string');
      return projectNameFromPath(root);
    } catch {}
  }
  return null;
}

function sameUsage(left, right) {
  return left && right
    && left.input_tokens === right.input_tokens
    && left.cached_input_tokens === right.cached_input_tokens
    && left.output_tokens === right.output_tokens
    && left.total_tokens === right.total_tokens;
}

function subtractUsage(total, prior) {
  const fields = ['input_tokens', 'cached_input_tokens', 'output_tokens', 'total_tokens'];
  if (!fields.every(field => tokenNumber(total?.[field]) !== null)) return null;
  if (!prior) return total;
  if (!fields.every(field => total[field] >= prior[field])) return null;
  return Object.fromEntries(fields.map(field => [field, total[field] - prior[field]]));
}

async function parseLog(file) {
  const rows = [];
  const fallbackRows = [];
  const contextByTurn = new Map();
  const rowsBeforeContext = [];
  let currentModel = '未标注模型';
  let sessionId = '';
  let project = null;
  let lastCumulative = null;
  let responseRows = 0;
  let skipped = 0;

  for await (const line of linesFromFile(file.file, file.isZstd)) {
    if (!line.includes('token_usage_record') && !line.includes('token_count')
      && !line.includes('turn_context') && !line.includes('session_meta')) continue;
    let record;
    try {
      record = JSON.parse(line);
    } catch {
      skipped++;
      continue;
    }
    const payload = record.payload || {};
    if (record.type === 'session_meta') {
      if (typeof payload.id === 'string') sessionId = payload.id;
      const root = typeof payload.cwd === 'string'
        ? payload.cwd
        : payload.runtime_workspace_roots?.find(value => typeof value === 'string');
      project = projectNameFromPath(root);
      continue;
    }
    if (record.type === 'turn_context') {
      if (typeof payload.model === 'string' && payload.model) currentModel = payload.model;
      if (typeof payload.turn_id === 'string' && payload.turn_id) {
        const prior = contextByTurn.get(payload.turn_id);
        const reasoningEffort = normalizeReasoningEffort(payload.effort);
        contextByTurn.set(payload.turn_id, {
          model: currentModel,
          reasoningEffort,
          ambiguous: Boolean(prior && (prior.ambiguous || prior.model !== currentModel
            || prior.reasoningEffort !== reasoningEffort)),
        });
      }
      continue;
    }
    if (record.type === 'token_usage_record') {
      const context = contextByTurn.get(payload.turn_id);
      const row = usageRow({
        timestamp: record.timestamp,
        responseId: payload.response_id,
        // session_id is retained as the first-version distribution key. It can
        // differ from thread_id in multi-agent logs, so changing it would make
        // previously cached session counts incomparable.
        sessionId: payload.session_id || payload.thread_id || sessionId,
        model: context?.model || currentModel,
        usage: payload.usage,
        estimated: false,
      });
      if (row) {
        if (context?.reasoningEffort) row.reasoningEffort = context.reasoningEffort;
        // Some logs emit usage before writing its turn context.
        if (!context && typeof payload.turn_id === 'string' && payload.turn_id) {
          rowsBeforeContext.push({ row, turnId: payload.turn_id });
        }
        rows.push(row);
        responseRows++;
      } else {
        skipped++;
      }
      continue;
    }
    if (record.type === 'event_msg' && payload.type === 'token_count' && responseRows === 0) {
      const cumulative = payload.info?.total_token_usage;
      if (!cumulative || sameUsage(cumulative, lastCumulative)) continue;
      const increment = subtractUsage(cumulative, lastCumulative);
      lastCumulative = cumulative;
      const row = usageRow({
        timestamp: record.timestamp,
        sessionId,
        model: currentModel,
        usage: increment,
        estimated: true,
      });
      if (row) fallbackRows.push(row);
      else skipped++;
    }
  }
  for (const { row, turnId } of rowsBeforeContext) {
    const context = contextByTurn.get(turnId);
    if (context && !context.ambiguous) {
      row.model = context.model;
      if (context.reasoningEffort) row.reasoningEffort = context.reasoningEffort;
    }
  }
  const selectedRows = responseRows > 0 ? rows : fallbackRows;
  return { rows: selectedRows, project, skipped, parsed: selectedRows.length };
}

function outputRow(row, project) {
  const { responseKey, ...rest } = row;
  return { ...rest, project: project || null };
}

/**
 * Reads usage and turn metadata. Raw paths, IDs, prompts and response content
 * do not enter the returned data or cache.
 */
export async function collectCodex({ dataDir, onProgress = () => {} } = {}) {
  const cacheFile = path.join(dataDir || path.join(process.cwd(), 'data'), 'codex-local-cache.json');
  const cache = await readCache(cacheFile);
  const files = await discoverLogs();
  const nextFiles = {};
  let parsed = 0;
  let skipped = 0;
  let reused = 0;
  let failed = 0;

  for (let index = 0; index < files.length; index++) {
    const file = files[index];
    const cached = cache.files[file.cacheKey];
    let result;
    if (cached && cached.size === file.size && cached.mtimeMs === file.mtimeMs && Array.isArray(cached.rows)) {
      result = cached;
      reused++;
    } else {
      try {
        result = await parseLog(file);
      } catch {
        skipped++;
        failed++;
        onProgress({ id: 'codex', processed: index + 1, total: files.length });
        continue;
      }
    }
    let project = result.project || null;
    if (!project) {
      try {
        project = await readProject(file);
      } catch {}
    }
    nextFiles[file.cacheKey] = {
      size: file.size,
      mtimeMs: file.mtimeMs,
      rows: result.rows,
      project,
      parsed: result.parsed || 0,
      skipped: result.skipped || 0,
    };
    parsed += result.parsed || 0;
    skipped += result.skipped || 0;
    onProgress({ id: 'codex', processed: index + 1, total: files.length });
  }
  await saveCache(cacheFile, { version: CACHE_VERSION, files: nextFiles });

  const responseKeys = new Set();
  const rows = [];
  for (const file of Object.values(nextFiles)) {
    for (const row of file.rows) {
      if (row.responseKey) {
        if (responseKeys.has(row.responseKey)) continue;
        responseKeys.add(row.responseKey);
      }
      rows.push(outputRow(row, file.project));
    }
  }
  const fallback = rows.some(row => row.estimated);
  const unavailable = rows.length === 0;
  const baseNote = unavailable
    ? '未发现可统计的本机 Codex 用量'
    : (fallback ? '含旧日志累计值回退，已标记为估算' : '本机日志请求级实测');
  return {
    rows,
    status: {
      id: 'codex',
      name: 'Codex',
      quality: unavailable ? 'estimated' : (fallback ? 'mixed' : 'measured'),
      note: skipped ? baseNote + '，跳过 ' + String(skipped) + ' 条无效记录' : baseNote,
      files: files.length,
      parsed,
      skipped,
      reused,
      ...(failed ? { failed } : {}),
      ...(unavailable ? { unavailable: true } : {}),
    },
  };
}
