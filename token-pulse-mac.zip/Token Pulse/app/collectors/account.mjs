import { spawn } from 'node:child_process';

const codexBinary = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex';
const maximumOutputBytes = 256 * 1024;

function safeWhole(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

function safeDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}

function readMessages(buffer) {
  return buffer.split('\n').flatMap(line => {
    try {
      return [JSON.parse(line)];
    } catch {
      return [];
    }
  });
}

export async function getCodexAccount() {
  return new Promise(resolve => {
    const child = spawn(codexBinary, ['app-server', '--listen', 'stdio://'], {
      stdio: ['pipe', 'pipe', 'ignore'],
      env: { ...process.env },
    });
    let received = '';
    let settled = false;
    let initialized = false;
    const finish = value => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      child.kill();
      resolve(value);
    };
    const send = message => child.stdin.write(JSON.stringify(message) + '\n');
    const timeout = setTimeout(() => finish({
      available: false, daily: [], lifetime: null, note: 'Codex 账号汇总读取超时',
    }), 8_000);

    child.stdin.on('error', () => finish({
      available: false, daily: [], lifetime: null, note: 'Codex 账号服务不可用',
    }));
    child.on('error', () => finish({
      available: false, daily: [], lifetime: null, note: '无法启动本机 Codex 账号服务',
    }));
    child.stdout.on('data', chunk => {
      received += chunk.toString('utf8');
      if (Buffer.byteLength(received) > maximumOutputBytes) {
        finish({ available: false, daily: [], lifetime: null, note: 'Codex 账号响应异常' });
        return;
      }
      for (const message of readMessages(received)) {
        if (message.id === 0 && message.result && !initialized) {
          initialized = true;
          received = '';
          send({ method: 'initialized', params: {} });
          send({ method: 'account/usage/read', id: 7 });
          continue;
        }
        if (message.id === 7 && message.error) {
          finish({ available: false, daily: [], lifetime: null, note: 'Codex 账号未授权读取用量' });
          return;
        }
        if (message.id !== 7 || !message.result) continue;
        const result = message.result;
        const daily = Array.isArray(result.dailyUsageBuckets)
          ? result.dailyUsageBuckets.flatMap(bucket => {
            const date = safeDate(bucket?.startDate);
            const total = safeWhole(bucket?.tokens);
            return date && total !== null ? [{ date, total }] : [];
          })
          : [];
        finish({
          available: true,
          daily,
          lifetime: safeWhole(result.summary?.lifetimeTokens),
          note: daily.length ? '来自 Codex 官方账号日汇总，仅用于对照' : 'Codex 官方账号未返回日汇总',
        });
      }
    });
    child.on('exit', code => {
      if (!settled) finish({
        available: false, daily: [], lifetime: null,
        note: code === 0 ? 'Codex 账号服务未返回用量' : 'Codex 账号服务不可用',
      });
    });
    send({
      method: 'initialize',
      id: 0,
      params: {
        clientInfo: {
          name: 'my-compute-dashboard',
          title: '我的算力看板',
          version: '1.0.0',
        },
      },
    });
  });
}
