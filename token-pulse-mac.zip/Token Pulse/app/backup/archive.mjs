import {
  createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID, scrypt,
} from 'node:crypto';
import { constants, createWriteStream } from 'node:fs';
import { appendFile, copyFile, link, open, unlink } from 'node:fs/promises';
import path from 'node:path';
import { PassThrough, Readable, Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { StringDecoder } from 'node:string_decoder';
import { promisify } from 'node:util';
import { createGunzip, createGzip } from 'node:zlib';

const magic = Buffer.from('COMPUTE-BACKUP-1\n');
const plainMagic = Buffer.from('COMPUTE-BACKUP-2\n');
const saltLength = 16;
const ivLength = 12;
const headerLength = magic.length + saltLength + ivLength;
const tagLength = 16;
const minimumGzipLength = 20;
const chunkLength = 64 * 1024;
const lineLimit = 20 * 1024 * 1024;
const readFlags = constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK;
const noHardLink = new Set(['ENOTSUP', 'EOPNOTSUPP', 'EXDEV', 'EMLINK', 'EPERM']);
const derive = promisify(scrypt);

function keyFor(passphrase, salt) {
  return derive(passphrase, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

function line(data) {
  const bytes = Buffer.from(JSON.stringify(data) + '\n');
  if (bytes.length > lineLimit) throw new Error('Archive record exceeds format limit');
  return bytes;
}

function safeFileMeta(entry) {
  const { id, relativePath, project, size } = entry;
  if (typeof id !== 'string' || typeof relativePath !== 'string' || !Number.isSafeInteger(size)
      || size < 0 || id.length > 128 || relativePath.length > 4096 || path.posix.isAbsolute(relativePath)
      || relativePath.split('/').some(part => !part || part === '.' || part === '..')) {
    throw new Error('Invalid attachment metadata');
  }
  return { id, relativePath, project, size };
}

async function* archiveItems(manifest, records, files, onProgress) {
  yield line({ type: 'manifest', manifest });
  let messages = 0;
  const sessions = new Set();
  for await (const record of records) {
    sessions.add(record.source + ':' + record.sessionId);
    messages++;
    yield line({ type: 'message', record });
  }
  let processed = 0;
  for (const entry of files) {
    const file = safeFileMeta(entry);
    const handle = await open(entry.path, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const info = await handle.stat();
      if (!info.isFile() || info.size !== file.size) throw new Error('Attachment has changed');
      const hash = createHash('sha256');
      let bytes = 0;
      yield line({ type: 'file', file });
      for await (const chunk of handle.createReadStream({ highWaterMark: chunkLength, autoClose: false })) {
        hash.update(chunk);
        bytes += chunk.length;
        if (bytes > file.size) throw new Error('Attachment has changed');
        yield line({ type: 'chunk', id: file.id, data: chunk.toString('base64') });
      }
      const after = await handle.stat();
      if (bytes !== file.size || info.mtimeMs !== after.mtimeMs) throw new Error('Attachment has changed');
      yield line({ type: 'fileEnd', id: file.id, sha256: hash.digest('hex') });
    } finally {
      await handle.close();
    }
    processed++;
    onProgress?.({ phase: 'attachments', processed, total: files.length });
  }
  yield line({ type: 'footer', counts: { messages, files: processed, conversations: sessions.size } });
}

export async function writeBackup({ target, passphrase, manifest, records, files, onProgress }) {
  const temporary = path.join(path.dirname(target), '.writing-' + randomUUID());
  const encrypted = passphrase !== null;
  let header = plainMagic;
  let key;
  let cipher;
  try {
    if (encrypted) {
      const salt = randomBytes(saltLength);
      const iv = randomBytes(ivLength);
      header = Buffer.concat([magic, salt, iv]);
      key = await keyFor(passphrase, salt);
      cipher = createCipheriv('aes-256-gcm', key, iv);
      cipher.setAAD(header);
    }
    const initial = await open(temporary, 'wx', 0o600);
    try {
      await initial.writeFile(header);
    } finally {
      await initial.close();
    }
    await pipeline(
      Readable.from(archiveItems(manifest, records, files, onProgress)),
      createGzip({ level: 6 }),
      ...(cipher ? [cipher] : []),
      createWriteStream(temporary, { flags: 'a' })
    );
    if (cipher) await appendFile(temporary, cipher.getAuthTag());
    const output = await open(temporary, 'r+');
    try {
      await output.sync();
    } finally {
      await output.close();
    }
    try {
      await link(temporary, target);
    } catch (error) {
      if (!noHardLink.has(error.code)) throw error;
      // Some removable filesystems cannot publish a completed archive by hard link.
      await copyFile(temporary, target, constants.COPYFILE_EXCL);
    }
  } finally {
    key?.fill(0);
    await unlink(temporary).catch(() => {});
  }
}

async function getBytes(handle, length, position) {
  const buffer = Buffer.alloc(length);
  const { bytesRead } = await handle.read(buffer, 0, length, position);
  if (bytesRead !== length) throw new Error('Incomplete backup');
  return buffer;
}

async function inspect(handle) {
  const stats = await handle.stat();
  if (!stats.isFile() || stats.size <= magic.length) throw new Error('Invalid backup');
  const { size } = stats;
  const prefix = await getBytes(handle, magic.length, 0);
  if (prefix.equals(magic) && size >= headerLength + tagLength + minimumGzipLength) {
    return { encrypted: true, size };
  }
  if (prefix.equals(plainMagic) && size >= plainMagic.length + minimumGzipLength) {
    const gzipHeader = await getBytes(handle, 3, plainMagic.length);
    if (gzipHeader.equals(Buffer.from([0x1f, 0x8b, 0x08]))) return { encrypted: false, size };
  }
  throw new Error('Unknown or incomplete backup format');
}

export async function inspectBackup({ file }) {
  const handle = await open(file, readFlags);
  try {
    const { encrypted } = await inspect(handle);
    return { encrypted };
  } finally {
    await handle.close();
  }
}

async function* lines(stream) {
  const decoder = new StringDecoder('utf8');
  let pending = '';
  for await (const chunk of stream) {
    pending += decoder.write(chunk);
    let newline;
    while ((newline = pending.indexOf('\n')) >= 0) {
      if (newline > lineLimit) throw new Error('Invalid archive record size');
      yield pending.slice(0, newline);
      pending = pending.slice(newline + 1);
    }
    if (pending.length > lineLimit) throw new Error('Invalid archive record size');
  }
  if (pending + decoder.end()) throw new Error('Incomplete archive record');
}

async function readItems(stream, onItem) {
  let manifest;
  let current;
  let footer;
  let messages = 0;
  const completedFiles = new Set();
  const sessions = new Set();
  for await (const raw of lines(stream)) {
    const item = JSON.parse(raw);
    if (footer || (!manifest && item.type !== 'manifest')) throw new Error('Invalid archive sequence');
    switch (item.type) {
      case 'manifest':
        if (manifest || !item.manifest || typeof item.manifest !== 'object' || Array.isArray(item.manifest)) {
          throw new Error('Invalid manifest');
        }
        manifest = item.manifest;
        break;
      case 'message':
        if (current || !item.record || typeof item.record.text !== 'string'
          || typeof item.record.source !== 'string' || typeof item.record.sessionId !== 'string') {
          throw new Error('Invalid message');
        }
        messages++;
        sessions.add(item.record.source + ':' + item.record.sessionId);
        break;
      case 'file': {
        if (current || completedFiles.has(item.file?.id)) throw new Error('Duplicate attachment');
        const file = safeFileMeta(item.file);
        current = { ...file, hash: createHash('sha256'), bytes: 0 };
        break;
      }
      case 'chunk': {
        if (!current || item.id !== current.id || typeof item.data !== 'string'
          || item.data.length > Math.ceil(chunkLength / 3) * 4) throw new Error('Invalid attachment chunk');
        const chunk = Buffer.from(item.data, 'base64');
        if (chunk.toString('base64') !== item.data) throw new Error('Invalid attachment encoding');
        current.bytes += chunk.length;
        if (current.bytes > current.size) throw new Error('Invalid attachment size');
        current.hash.update(chunk);
        break;
      }
      case 'fileEnd':
        if (!current || item.id !== current.id || current.bytes !== current.size
          || current.hash.digest('hex') !== item.sha256) throw new Error('Attachment checksum mismatch');
        completedFiles.add(current.id);
        current = null;
        break;
      case 'footer':
        if (current || item.counts?.messages !== messages || item.counts?.files !== completedFiles.size
          || item.counts?.conversations !== sessions.size) throw new Error('Backup counts do not match');
        footer = item.counts;
        break;
      default:
        throw new Error('Unsupported archive record');
    }
    await onItem?.(item);
  }
  if (!manifest || !footer) throw new Error('Backup manifest or footer is missing');
  return { manifest, counts: footer };
}

export async function readBackup({ file, passphrase, onItem }) {
  const handle = await open(file, readFlags);
  let key;
  try {
    const { encrypted, size } = await inspect(handle);
    const source = () => handle.createReadStream({
      autoClose: false,
      start: encrypted ? headerLength : plainMagic.length,
      end: encrypted ? size - tagLength - 1 : size - 1,
    });
    let decipher;
    if (encrypted) {
      if (typeof passphrase !== 'string') throw new Error('Missing backup passphrase');
      const header = await getBytes(handle, headerLength, 0);
      const salt = header.subarray(magic.length, magic.length + saltLength);
      const iv = header.subarray(magic.length + saltLength);
      const tag = await getBytes(handle, tagLength, size - tagLength);
      key = await keyFor(passphrase, salt);
      decipher = () => {
        const stream = createDecipheriv('aes-256-gcm', key, iv);
        stream.setAAD(header);
        stream.setAuthTag(tag);
        return stream;
      };
      await pipeline(source(), decipher(), new Writable({
        write(_chunk, _encoding, callback) { callback(); },
      }));
    }
    const output = new PassThrough();
    const decompression = pipeline(
      source(), ...(decipher ? [decipher()] : []), createGunzip(), output
    ).then(
      () => null, error => error
    );
    try {
      const result = await readItems(output, onItem);
      const failure = await decompression;
      if (failure) throw failure;
      return result;
    } finally {
      output.destroy();
      await decompression;
    }
  } finally {
    key?.fill(0);
    await handle.close();
  }
}
