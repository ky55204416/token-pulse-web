import { createHash } from 'node:crypto';
import { lstat, readdir, realpath } from 'node:fs/promises';
import path from 'node:path';

export const categories = [
  { id: 'image', name: '截图与图片' },
  { id: 'video', name: '视频' },
  { id: 'spreadsheet', name: '表格' },
  { id: 'process', name: '过程文件' },
  { id: 'result', name: '结果与项目文件' },
];

const extensions = {
  image: new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.heic', '.tiff', '.avif', '.bmp']),
  video: new Set(['.mp4', '.mov', '.m4v', '.webm', '.mkv', '.avi']),
  spreadsheet: new Set(['.xls', '.xlsx', '.xlsm', '.ods', '.csv', '.tsv']),
  project: new Set(['.md', '.txt', '.pdf', '.doc', '.docx', '.ppt', '.pptx', '.rtf', '.odt',
    '.html', '.css', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.py', '.sh',
    '.command', '.json', '.yml', '.yaml', '.sql', '.ipynb', '.svg', '.wav', '.mp3', '.zip']),
};
const ignored = new Set(['node_modules', '__pycache__', 'vendor', 'venv', 'credentials',
  'secrets', '恢复文件', '备份']);
const ignoredFile = /(^|[.\-_])(?:auth|credentials?|secrets?|passwords?|tokens?)(?:[.\-_]|$)/i;

function classify(relative, name) {
  if (ignoredFile.test(name)) return null;
  const extension = path.extname(name).toLowerCase();
  for (const category of ['image', 'video', 'spreadsheet']) {
    if (extensions[category].has(extension)) return category;
  }
  if (!extensions.project.has(extension)) return null;
  return relative.split(path.sep).some(part => /^(过程|process|work|scratch|草稿|初稿|临时)$/i.test(part))
    ? 'process' : 'result';
}

function identity(relative, stats) {
  return createHash('sha256')
    .update(JSON.stringify([relative, stats.dev, stats.ino, stats.size, stats.mtimeMs]))
    .digest('hex').slice(0, 32);
}

function within(root, file) {
  const relative = path.relative(root, file);
  return relative && relative !== '..' && !relative.startsWith('..' + path.sep)
    && !path.isAbsolute(relative);
}

export async function discoverProjectFiles(root, { limit = 8000 } = {}) {
  const base = await realpath(root);
  const files = [];
  let omitted = 0;
  async function walk(directory) {
    let entries;
    try {
      entries = await readdir(directory, { withFileTypes: true });
    } catch {
      omitted++;
      return;
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.') || ignored.has(entry.name.toLowerCase())) continue;
      if (files.length >= limit) {
        omitted++;
        break;
      }
      const file = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        await walk(file);
        continue;
      }
      if (!entry.isFile()) continue;
      const relative = path.relative(base, file);
      const category = classify(relative, entry.name);
      if (!category) continue;
      try {
        const stats = await lstat(file);
        if (!stats.isFile()) continue;
        const parts = relative.split(path.sep);
        files.push({
          id: identity(relative, stats),
          path: file,
          relativePath: parts.join('/'),
          project: parts.length > 1 ? parts[0] : '项目管理目录',
          name: entry.name,
          size: stats.size,
          category,
        });
      } catch {
        omitted++;
      }
    }
  }
  await walk(base);
  files.sort((a, b) => a.project.localeCompare(b.project, 'zh-CN')
    || a.relativePath.localeCompare(b.relativePath, 'zh-CN'));
  return { files, omitted };
}

export async function validateProjectFiles(root, files) {
  const base = await realpath(root);
  for (const file of files) {
    const resolved = await realpath(file.path);
    if (!within(base, resolved) || resolved !== file.path) return false;
    const stats = await lstat(resolved);
    const relative = path.relative(base, resolved);
    if (!stats.isFile() || identity(relative, stats) !== file.id) return false;
  }
  return true;
}
