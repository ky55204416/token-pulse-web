import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { constants, createReadStream } from 'node:fs';
import { chmod, lstat, mkdir, open, readdir, realpath, rename, rm, statfs } from 'node:fs/promises';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { gzipSync } from 'node:zlib';
import { categories, discoverProjectFiles, validateProjectFiles } from './files.mjs';
import { chooseBackupDirectory, importBackupUpload, StorageError } from './storage.mjs';

const suffix = '.compute-backup';
const lightPrefix = '智脉轻量备份_';
const fullPrefix = '我的算力备份_';
const lightManifestLimit = 8 * 1024 * 1024;
const scanLifetime = 15 * 60 * 1000;
const requestLimit = 1024 * 1024;
const maxConversations = 40;
const maxMessages = 30;
const displayBudget = 1024 * 1024;
const archiveName = /^[\p{L}\p{N}_-][\p{L}\p{N} _.-]{0,190}\.compute-backup$/u;

class RequestError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function bodyFor(request) {
  if (request.headers['content-type']?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new RequestError(415, '请使用看板的备份页面提交请求。');
  }
  if (Number(request.headers['content-length']) > requestLimit) {
    throw new RequestError(413, '请求过大，请减少一次选择的文件。');
  }
  const chunks = [];
  let bytes = 0;
  for await (const chunk of request) {
    bytes += chunk.length;
    if (bytes > requestLimit) throw new RequestError(413, '请求过大。');
    chunks.push(chunk);
  }
  try {
    const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (body && typeof body === 'object' && !Array.isArray(body)) return body;
  } catch {}
  throw new RequestError(400, '无法识别本次请求。');
}

function requirePassphrase(value, minimum) {
  if (typeof value !== 'string' || value.length < minimum || value.length > 256) {
    throw new RequestError(400, minimum > 1 ? '请设置 10 至 256 个字符的备份密码。' : '请输入备份密码。');
  }
}

function selected(data, key, allowed) {
  if (!Array.isArray(data[key]) || data[key].some(id => typeof id !== 'string' || !allowed.has(id))) {
    throw new RequestError(400, '备份选择已失效，请重新预估。');
  }
  return new Set(data[key]);
}

function stamp(date) {
  const format = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Asia/Singapore', dateStyle: 'short', timeStyle: 'medium',
  });
  return format.format(date).replace(' ', '_').replaceAll(':', '-');
}

function publicFile(file) {
  const { id, name, relativePath, project, category, size } = file;
  return { id, name, relativePath, project, category, size };
}

function summarizeSources(entries, descriptions) {
  return descriptions.map(source => {
    const files = entries.filter(entry => entry.source === source.id);
    return {
      id: source.id, name: source.name, note: source.note ?? '',
      available: source.available && files.length > 0,
      sessionCount: files.reduce((sum, file) => sum + (file.sessionCount ?? 1), 0),
      bytes: files.reduce((sum, file) => sum + (file.bytes || 0), 0),
    };
  });
}

function itemText(record) {
  return typeof record?.text === 'string' ? record.text : '';
}

async function sampleRange(entries, readHistory) {
  let minBytes = 0;
  let maxBytes = 0;
  let sampled = 0;
  for (const compressed of [false, true]) {
    const group = entries.filter(entry => Boolean(entry.isZstd) === compressed);
    const sourceBytes = group.reduce((sum, entry) => sum + entry.bytes, 0);
    if (!sourceBytes) continue;
    const candidates = group.filter(entry => entry.bytes > 0 && entry.bytes <= 512 * 1024)
      .sort((a, b) => a.bytes - b.bytes);
    const positions = new Set([0.2, 0.55, 0.85].map(q => Math.floor((candidates.length - 1) * q)));
    let measuredOutput = 0;
    let measuredInput = 0;
    for (const index of positions) {
      if (!candidates[index]) continue;
      const entry = candidates[index];
      const text = [];
      let length = 0;
      try {
        for await (const record of readHistory(entry, { byteLimit: 8 * 1024 * 1024 })) {
          const line = JSON.stringify(record);
          length += line.length;
          if (length > 512 * 1024) break;
          text.push(line);
        }
        if (!text.length) continue;
        measuredOutput += gzipSync(text.join('\n')).length;
        measuredInput += entry.bytes;
        sampled++;
      } catch {}
    }
    const projected = measuredInput ? sourceBytes * measuredOutput / measuredInput : 0;
    minBytes += projected ? projected / 4 : sourceBytes * 0.05;
    maxBytes += projected ? Math.min(projected * 4, sourceBytes * 1.5) : sourceBytes * 1.2;
  }
  return {
    minBytes: Math.floor(minBytes),
    maxBytes: Math.ceil(Math.max(minBytes, maxBytes)),
    method: sampled ? '抽样' : '原始体积',
  };
}

function safeFileName(value) {
  const base = path.basename(typeof value === 'string' ? value : 'attachment');
  const cleaned = base.replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_').replace(/^\.+$/, 'attachment').slice(0, 180);
  return cleaned || 'attachment';
}

function base64Chunk(value) {
  if (typeof value !== 'string' || value.length > 32 * 1024 * 1024 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    throw new RequestError(422, '备份附件数据无效。');
  }
  return Buffer.from(value, 'base64');
}

export function createBackupService({ folder, projectRoot, getDashboard, getLightBackup, chooseDirectory = chooseBackupDirectory }) {
  const scans = new Map();
  const jobs = new Map();
  const destinations = new Map();
  const defaultDestination = { id: null, folder, label: '我的算力看板 / 备份' };
  let inProgress = null;
  let estimating;
  let reading = false;
  let choosingDirectory = false;

  async function diskFree(directory = folder) {
    try {
      const info = await statfs(directory).catch(error => {
        if (directory !== folder || error.code !== 'ENOENT') throw error;
        return statfs(path.dirname(folder));
      });
      return info.bavail * info.bsize;
    } catch {
      return null;
    }
  }

  function destinationFor(id) {
    if (id === null || id === undefined) return defaultDestination;
    const destination = destinations.get(id);
    if (!destination) throw new RequestError(410, '保存位置已失效，请重新选择文件夹。');
    return destination;
  }

  async function usableDirectory(destination, create = false) {
    try {
      if (create && !destination.id) await mkdir(destination.folder, { recursive: true, mode: 0o700 });
      const info = await lstat(destination.folder);
      if (!info.isDirectory() || (destination.id && (info.dev !== destination.dev || info.ino !== destination.ino
        || await realpath(destination.folder) !== destination.folder))) throw new Error();
      return destination.folder;
    } catch {
      throw new RequestError(409, '备份文件夹已不可用，请检查磁盘或重新选择位置。');
    }
  }

  async function chooseDestination() {
    if (choosingDirectory) throw new RequestError(409, '请先完成已打开的保存位置选择。');
    choosingDirectory = true;
    try {
      const chosen = await chooseDirectory();
      if (!chosen) return { destination: null };
      const directory = await realpath(chosen).catch(() => null);
      const info = directory && await lstat(directory).catch(() => null);
      if (!info?.isDirectory()) throw new RequestError(409, '所选保存位置不可用。');
      const defaultPath = await realpath(folder).catch(() => folder);
      let destination = directory === defaultPath ? defaultDestination
        : [...destinations.values()].find(item => item.folder === directory && item.dev === info.dev && item.ino === info.ino);
      if (!destination) {
        destination = { id: randomUUID(), folder: directory, label: directory, dev: info.dev, ino: info.ino };
        if (destinations.size >= 24) destinations.delete(destinations.keys().next().value);
        destinations.set(destination.id, destination);
      }
      return { destination: {
        id: destination.id, label: destination.label, freeBytes: await diskFree(directory),
      } };
    } finally {
      choosingDirectory = false;
    }
  }

  function saveScan(scan) {
    const scanId = randomUUID();
    const time = Date.now();
    for (const [id, item] of scans) {
      if (time - item.time > scanLifetime) scans.delete(id);
    }
    if (scans.size >= 4) scans.delete(scans.keys().next().value);
    scans.set(scanId, { ...scan, time });
    return scanId;
  }

  function estimate() {
    if (estimating) return estimating;
    estimating = (async () => {
      const { discoverHistory, readHistory } = await import('./sources.mjs');
      const [history, attachments, freeBytes] = await Promise.all([
        discoverHistory(), discoverProjectFiles(projectRoot), diskFree(),
      ]);
      const sources = summarizeSources(history.entries, history.sources);
      await Promise.all(sources.filter(source => source.available).map(async source => {
        source.sampleEstimate = await sampleRange(history.entries.filter(entry => entry.source === source.id), readHistory);
      }));
      const generatedAt = new Date().toISOString();
      const scanId = saveScan({ mode: 'full', entries: history.entries, files: attachments.files, sources });
      return {
        scanId, sources, files: attachments.files.map(publicFile), categories, generatedAt,
        attachmentScope: '当前项目管理目录',
        omitted: attachments.omitted,
        destination: { label: '我的算力看板 / 备份', freeBytes },
        estimate: {
          originalBytes: sources.reduce((sum, source) => sum + source.bytes, 0),
          minBytes: sources.reduce((sum, source) => sum + (source.sampleEstimate?.minBytes || 0), 0),
          maxBytes: sources.reduce((sum, source) => sum + (source.sampleEstimate?.maxBytes || 0), 65536),
        },
      };
    })().finally(() => { estimating = null; });
    return estimating;
  }

  async function lightEstimate() {
    const snapshot = getLightBackup?.();
    if (!snapshot) throw new RequestError(503, '用量尚未就绪，请稍后重新预估。');
    const { generatedAt, from, to, projects } = structuredClone(snapshot);
    const summaries = projects.map(project => ({
      id: project.id, name: project.name, total: project.total, sessions: project.sessions,
      from: project.from, to: project.to, modelCount: project.models.length,
      bytes: Buffer.byteLength(JSON.stringify(project)),
    }));
    const scanId = saveScan({ mode: 'light', usage: { generatedAt, from, to, projects } });
    return {
      scanId, projects: summaries, from, to, generatedAt,
      destination: { label: '我的算力看板 / 备份', freeBytes: await diskFree() },
    };
  }

  function enqueue(job, run) {
    const jobId = randomUUID();
    inProgress = jobId;
    jobs.set(jobId, job);
    if (jobs.size > 12) jobs.delete(jobs.keys().next().value);
    void run(jobId).finally(() => { inProgress = null; });
    return { jobId };
  }

  async function start(body) {
    if (inProgress || reading) throw new RequestError(409, '已有备份任务在运行，请稍后重试。');
    if (body.encrypted !== undefined && typeof body.encrypted !== 'boolean') {
      throw new RequestError(400, '无法识别密码保护选项。');
    }
    const passphrase = body.encrypted === false ? null : body.passphrase;
    if (body.encrypted !== false) requirePassphrase(passphrase, 10);
    const destination = destinationFor(body.destinationId);
    const mode = body.mode ?? 'full';
    if (mode !== 'full' && mode !== 'light') throw new RequestError(400, '无法识别备份模式。');
    const scan = scans.get(body.scanId);
    if (!scan || scan.mode !== mode || Date.now() - scan.time > scanLifetime) {
      throw new RequestError(410, '这次估算已过期，请重新预估。');
    }
    if (mode === 'light') return startLight(body, scan.usage, destination, passphrase);
    const sourceIds = selected(body, 'sources', new Set(scan.sources
      .filter(source => source.available).map(source => source.id)));
    const fileIds = selected(body, 'files', new Set(scan.files.map(file => file.id)));
    if (!sourceIds.size && !fileIds.size) throw new RequestError(400, '请选择要备份的内容。');
    const entries = scan.entries.filter(entry => sourceIds.has(entry.source));
    const files = scan.files.filter(file => fileIds.has(file.id));
    const sources = scan.sources.filter(source => sourceIds.has(source.id));
    const job = { state: 'running', phase: '检查文件', processed: 0, total: entries.length + files.length };
    return enqueue(job, jobId => write(passphrase, job, { entries, files, sources, jobId, destination }));
  }

  function startLight(body, usage, destination, passphrase) {
    const ids = selected(body, 'projects', new Set(usage.projects.map(project => project.id)));
    if (!ids.size) throw new RequestError(400, '请至少选择一个要备份的项目。');
    const projects = usage.projects.filter(project => ids.has(project.id));
    const from = projects.reduce((first, project) => project.from < first ? project.from : first, projects[0].from);
    const to = projects.reduce((last, project) => project.to > last ? project.to : last, projects[0].to);
    const now = new Date();
    const manifest = {
      title: '智脉轻量备份', createdAt: now.toISOString(), mode: 'light', files: [],
      usage: { generatedAt: usage.generatedAt, from, to, projects },
    };
    if (Buffer.byteLength(JSON.stringify(manifest)) > lightManifestLimit) {
      throw new RequestError(413, '用量摘要过大，请减少一次备份选择的项目。');
    }
    const job = {
      state: 'running', phase: '写入用量摘要', mode: 'light', processed: 0, total: projects.length,
    };
    return enqueue(job, jobId => writeLight(passphrase, job, { jobId, manifest, now, destination }));
  }

  async function writeLight(passphrase, job, { jobId, manifest, now, destination }) {
    try {
      const { writeBackup } = await import('./archive.mjs');
      const directory = await usableDirectory(destination, true);
      const fileName = `${lightPrefix}${stamp(now)}_${jobId.slice(0, 8)}${suffix}`;
      const target = path.join(directory, fileName);
      await writeBackup({ target, passphrase, manifest, records: [], files: [] });
      const info = await lstat(target);
      const projects = manifest.usage.projects;
      Object.assign(job, {
        state: 'complete', phase: '轻量备份已完成', message: '轻量备份已完成',
        processed: job.total, fileName, bytes: info.size,
        location: destination.label,
        counts: { projects: projects.length, models: projects.reduce((sum, p) => sum + p.models.length, 0) },
      });
    } catch (error) {
      Object.assign(job, {
        state: 'error', phase: '备份未完成',
        message: error instanceof RequestError ? error.message
          : error.code === 'ENOSPC' ? '备份空间不足，请释放空间后重试。'
            : '本次轻量备份没有完成。请确认备份目录可用后重试。',
      });
    }
  }

  async function write(passphrase, job, { entries, files, sources, jobId, destination }) {
    let skipped = 0;
    let messages = 0;
    const sessions = new Set();
    try {
      const valid = await validateProjectFiles(projectRoot, files).catch(() => false);
      if (!valid) throw new RequestError(409, '已选文件发生变化，请重新预估并选择。');
      const free = await diskFree(destination.folder);
      const attachmentBytes = files.reduce((sum, item) => sum + item.size, 0);
      if (free !== null && free < attachmentBytes) {
        throw new RequestError(507, '磁盘剩余空间低于所选附件的原始大小。请减少附件或释放空间。');
      }
      const [{ readHistory }, { writeBackup }] = await Promise.all([
        import('./sources.mjs'), import('./archive.mjs'),
      ]);
      const directory = await usableDirectory(destination, true);
      const now = new Date();
      const fileName = `${fullPrefix}${stamp(now)}_${jobId.slice(0, 8)}${suffix}`;
      const target = path.join(directory, fileName);
      const manifest = {
        title: '我的算力看板备份',
        createdAt: now.toISOString(),
        mode: 'full',
        sources: sources.map(({ id, name, sessionCount }) => ({ id, name, candidateSessions: sessionCount })),
        files: files.map(publicFile),
        dashboard: getDashboard(),
      };
      async function* records() {
        job.phase = '整理会话正文';
        for (const entry of entries) {
          try {
            for await (const record of readHistory(entry)) {
              if (!itemText(record).trim()) continue;
              sessions.add(`${record.source}:${record.sessionId}`);
              messages++;
              yield record;
            }
          } catch {
            skipped++;
          }
          job.processed++;
        }
        if (!messages && !files.length) throw new RequestError(422, '这次没有读到可备份的会话正文。');
        job.phase = files.length ? '写入附件' : '完成备份';
      }
      await writeBackup({
        target, passphrase, manifest, records: records(), files,
        onProgress(update) {
          if (update?.phase === 'attachments' && Number.isSafeInteger(update.processed)) {
            job.processed = Math.min(job.total, entries.length + update.processed);
          }
        },
      });
      const info = await lstat(target);
      Object.assign(job, {
        state: 'complete', phase: '备份已完成', processed: job.total, fileName, bytes: info.size,
        location: destination.label,
        counts: { conversations: sessions.size, messages, files: files.length, skipped },
      });
    } catch (error) {
      Object.assign(job, {
        state: 'error', phase: '备份未完成',
        message: error instanceof RequestError ? error.message
          : error.code === 'ENOSPC' ? '备份空间不足，请减少选项后重试。'
            : '本次备份没有完成。请确认所选文件和备份目录可用后重试。',
      });
    }
  }

  async function archiveFile(name, destinationId) {
    if (typeof name !== 'string' || !archiveName.test(name)) throw new RequestError(400, '备份文件名无效。');
    const destination = destinationFor(destinationId);
    try {
      const directory = await usableDirectory(destination);
      const file = path.join(directory, name);
      const info = await lstat(file);
      if (!info.isFile()) throw new Error();
      return { file, info };
    } catch {
      throw new RequestError(404, '在所选位置找不到备份文件。');
    }
  }

  function archiveMetadata(name, info, encrypted, destination) {
    const mode = name.startsWith(lightPrefix) ? 'light' : name.startsWith(fullPrefix) ? 'full' : null;
    return {
      name, mode, encrypted, bytes: info.size, createdAt: info.mtime.toISOString(),
      destinationId: destination.id, location: destination.label,
    };
  }

  async function list(destinationId) {
    const selected = destinationFor(destinationId);
    const locations = selected.id ? [defaultDestination, selected] : [defaultDestination];
    const { inspectBackup } = await import('./archive.mjs');
    const backups = [];
    for (const destination of locations) {
      const entries = await usableDirectory(destination)
        .then(directory => readdir(directory, { withFileTypes: true })).catch(() => []);
      for (const entry of entries) {
        if (!entry.isFile() || !archiveName.test(entry.name)) continue;
        try {
          const file = path.join(destination.folder, entry.name);
          const info = await lstat(file);
          const { encrypted } = await inspectBackup({ file });
          backups.push(archiveMetadata(entry.name, info, encrypted, destination));
        } catch {}
      }
    }
    backups.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { backups };
  }

  async function importArchive(request) {
    if (reading || inProgress) throw new RequestError(409, '已有备份任务在运行，请稍后再导入。');
    reading = true;
    try {
      const { inspectBackup, readBackup } = await import('./archive.mjs');
      const { name, info, encrypted, alreadyPresent } = await importBackupUpload({
        request, folder, inspectBackup, readBackup,
      });
      return { backup: archiveMetadata(name, info, encrypted, defaultDestination), alreadyPresent };
    } finally {
      reading = false;
    }
  }

  async function view(body) {
    if (reading || inProgress) throw new RequestError(409, '已有备份任务在运行，请稍后再查看。');
    reading = true;
    let encrypted = false;
    try {
      const { file } = await archiveFile(body.name, body.destinationId);
      const { inspectBackup, readBackup } = await import('./archive.mjs');
      ({ encrypted } = await inspectBackup({ file }));
      if (encrypted) requirePassphrase(body.passphrase, 1);
      const query = typeof body.query === 'string' ? body.query.trim().slice(0, 120).toLowerCase() : '';
      const conversations = new Map();
      const seen = new Set();
      let displayedBytes = 0;
      let truncated = false;
      const summary = await readBackup({
        file, passphrase: encrypted ? body.passphrase : null,
        onItem(item) {
          if (item.type !== 'message') return;
          const entry = item.record ?? item.data ?? item;
          const key = `${entry.source}:${entry.sessionId}`;
          seen.add(key);
          if (query && ![entry.title, entry.project, itemText(entry)].some(text => (
            typeof text === 'string' && text.toLowerCase().includes(query)
          ))) return;
          if (displayedBytes >= displayBudget || (!conversations.has(key) && conversations.size >= maxConversations)) {
            truncated = true;
            return;
          }
          const row = conversations.get(key) ?? {
            sessionId: entry.sessionId, source: entry.source, project: entry.project, title: entry.title, messages: [],
          };
          if (row.messages.length >= maxMessages) {
            truncated = true;
            return;
          }
          const text = itemText(entry).slice(0, 16000);
          if (itemText(entry).length > text.length) truncated = true;
          row.messages.push({ role: entry.role, text, at: entry.at });
          displayedBytes += Buffer.byteLength(text);
          conversations.set(key, row);
        },
      });
      const manifest = summary.manifest ?? {};
      return {
        manifest: {
          title: manifest.title, createdAt: manifest.createdAt, files: manifest.files, encrypted,
          ...(manifest.mode === 'light'
            ? { mode: 'light', usage: manifest.usage }
            : { mode: 'full', dashboard: manifest.dashboard }),
        },
        conversations: [...conversations.values()],
        counts: { ...(summary.counts ?? {}), conversations: seen.size },
        truncated,
      };
    } catch (error) {
      if (error instanceof RequestError) throw error;
      throw new RequestError(422, encrypted
        ? '无法打开备份。请检查密码和备份文件完整性。'
        : '无法打开备份。请检查备份文件完整性。');
    } finally {
      reading = false;
    }
  }

  async function restoreFile(body) {
    if (typeof body.fileId !== 'string' || !body.fileId || body.fileId.length > 256) {
      throw new RequestError(400, '请选择要恢复的备份文件。');
    }
    if (reading || inProgress) throw new RequestError(409, '已有备份任务在运行，请稍后再恢复文件。');
    reading = true;
    let stageDirectory = '';
    let stageFile = '';
    let finalDirectory = '';
    let handle;
    let encrypted = false;
    try {
      const { file } = await archiveFile(body.name, body.destinationId);
      const { inspectBackup, readBackup } = await import('./archive.mjs');
      ({ encrypted } = await inspectBackup({ file }));
      if (encrypted) requirePassphrase(body.passphrase, 1);
      const restoreRoot = path.join(folder, '恢复文件');
      const stagingRoot = path.join(folder, '.restore-staging');
      const privateId = randomUUID();
      let requested;
      let digest;
      let sawFile = false;
      let ended = false;
      let bytesWritten = 0;

      const summary = await readBackup({
        file, passphrase: encrypted ? body.passphrase : null,
        async onItem(item) {
          if (item.type === 'manifest') {
            if (requested) return;
            const manifestFiles = Array.isArray(item.manifest?.files) ? item.manifest.files : [];
            requested = manifestFiles.find(entry => entry && entry.id === body.fileId);
            if (!requested) throw new RequestError(404, '这份备份中找不到所选文件。');
            await usableDirectory(defaultDestination, true);
            await mkdir(stagingRoot, { recursive: true, mode: 0o700 });
            if (!(await lstat(stagingRoot)).isDirectory()) throw new RequestError(409, '暂存目录不可用。');
            await chmod(stagingRoot, 0o700);
            const stage = path.join(stagingRoot, privateId);
            await mkdir(stage, { mode: 0o700 });
            stageDirectory = stage;
            stageFile = path.join(stageDirectory, 'payload');
            handle = await open(stageFile, 'wx', 0o600);
            digest = createHash('sha256');
            return;
          }
          if (!requested) throw new RequestError(422, '备份缺少文件清单。');
          if (item.type === 'file' && item.file?.id === body.fileId) {
            sawFile = true;
            return;
          }
          if (item.type === 'chunk' && item.id === body.fileId) {
            const chunk = base64Chunk(item.data);
            bytesWritten += chunk.length;
            if (Number.isSafeInteger(requested.size) && bytesWritten > requested.size) {
              throw new RequestError(422, '备份文件大小校验失败。');
            }
            digest.update(chunk);
            const result = await handle.write(chunk);
            if (result.bytesWritten !== chunk.length) throw new RequestError(507, '恢复文件写入不完整。');
            return;
          }
          if (item.type === 'fileEnd' && item.id === body.fileId) {
            if (typeof item.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(item.sha256)) {
              throw new RequestError(422, '备份文件校验信息无效。');
            }
            const actual = Buffer.from(digest.digest('hex'), 'hex');
            const expected = Buffer.from(item.sha256, 'hex');
            if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
              throw new RequestError(422, '备份文件校验失败。');
            }
            ended = true;
          }
        },
      });
      if (!requested || !sawFile || !ended || !handle) throw new RequestError(422, '备份中没有可恢复的完整文件。');
      if (Number.isSafeInteger(requested.size) && bytesWritten !== requested.size) {
        throw new RequestError(422, '备份文件大小校验失败。');
      }
      await handle.sync();
      await handle.close();
      handle = undefined;
      // readBackup only resolves after a verified full archive pass; no final path exists before this point.
      const destination = path.join(restoreRoot, privateId);
      const finalName = safeFileName(requested.relativePath || requested.name);
      const finalFile = path.join(destination, finalName);
      await mkdir(restoreRoot, { recursive: true, mode: 0o700 });
      if (!(await lstat(restoreRoot)).isDirectory()) throw new RequestError(409, '恢复目录不可用。');
      await chmod(restoreRoot, 0o700);
      await mkdir(destination, { mode: 0o700 });
      finalDirectory = destination;
      await rename(stageFile, finalFile);
      await rm(stageDirectory, { recursive: true, force: true }).catch(() => {});
      return { location: path.posix.join('恢复文件', privateId, finalName), counts: summary.counts };
    } catch (error) {
      if (handle) await handle.close().catch(() => {});
      if (stageDirectory) await rm(stageDirectory, { recursive: true, force: true }).catch(() => {});
      if (finalDirectory) await rm(finalDirectory, { recursive: true, force: true }).catch(() => {});
      if (error instanceof RequestError) throw error;
      throw new RequestError(422, encrypted
        ? '无法恢复该文件。请检查密码和备份完整性。'
        : '无法恢复该文件。请检查备份完整性。');
    } finally {
      reading = false;
    }
  }

  return async (request, response, url, reply, headers) => {
    const action = url.pathname.split('/').at(-1);
    try {
      if (request.method === 'POST' && action === 'estimate') {
        await bodyFor(request);
        reply(response, 200, await estimate());
      } else if (request.method === 'POST' && action === 'lightestimate') {
        await bodyFor(request);
        reply(response, 200, await lightEstimate());
      } else if (request.method === 'POST' && action === 'destination') {
        await bodyFor(request);
        reply(response, 200, await chooseDestination());
      } else if (request.method === 'POST' && action === 'import') {
        reply(response, 200, await importArchive(request));
      } else if (request.method === 'POST' && action === 'start') {
        reply(response, 202, await start(await bodyFor(request)));
      } else if (request.method === 'GET' && action === 'status') {
        const job = jobs.get(url.searchParams.get('jobId'));
        if (!job) throw new RequestError(404, '找不到这次备份任务。');
        reply(response, 200, job);
      } else if (request.method === 'GET' && action === 'list') {
        reply(response, 200, await list(url.searchParams.get('destinationId')));
      } else if (request.method === 'POST' && action === 'view') {
        reply(response, 200, await view(await bodyFor(request)));
      } else if (request.method === 'POST' && action === 'restorefile') {
        reply(response, 200, await restoreFile(await bodyFor(request)));
      } else if (request.method === 'GET' && action === 'download') {
        const name = url.searchParams.get('name');
        const { file, info } = await archiveFile(name, url.searchParams.get('destinationId'));
        response.writeHead(200, {
          ...headers,
          'Content-Type': 'application/octet-stream',
          'Content-Length': info.size,
          'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
        });
        await pipeline(createReadStream(file, { flags: constants.O_RDONLY | constants.O_NOFOLLOW }), response);
      } else {
        throw new RequestError(404, '找不到备份操作。');
      }
    } catch (error) {
      if (response.headersSent) {
        response.destroy();
      } else {
        reply(response, error.status ?? 500, {
          error: error instanceof RequestError || error instanceof StorageError
            ? error.message : '暂时无法处理备份请求，可稍后重试。',
        });
      }
    }
  };
}
