import { execFile } from 'node:child_process';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import http from 'node:http';
import { userInfo } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildDashboard, buildLightBackup, dayOf } from './metrics.mjs';
import { createBackupService } from './backup/service.mjs';
import { createWebConnection } from './web-connection.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(root, '.data');
const snapshotFile = path.join(dataDir, 'dashboard-v1.json');
const port = Number(process.env.COMPUTE_DASHBOARD_PORT || 4317);
const localHosts = new Set(['127.0.0.1:' + port, 'localhost:' + port]);
const localUrl = 'http://127.0.0.1:' + port;
const viewer = { username: '' };
try { viewer.username = userInfo().username; } catch {}
const publicFiles = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'application/javascript; charset=utf-8'],
  '/units.js': ['units.js', 'application/javascript; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/insights.js': ['insights.js', 'application/javascript; charset=utf-8'],
  '/insights.css': ['insights.css', 'text/css; charset=utf-8'],
  '/report.js': ['report.js', 'application/javascript; charset=utf-8'],
  '/report.css': ['report.css', 'text/css; charset=utf-8'],
  '/welcome.js': ['welcome.js', 'application/javascript; charset=utf-8'],
  '/welcome.css': ['welcome.css', 'text/css; charset=utf-8'],
  '/backup.js': ['backup.js', 'application/javascript; charset=utf-8'],
  '/backup.css': ['backup.css', 'text/css; charset=utf-8'],
  '/pulse-icon.png': ['pulse-icon.png', 'image/png'],
};
const commonHeaders = {
  'Cache-Control': 'no-store',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
  'Referrer-Policy': 'no-referrer',
  'X-Content-Type-Options': 'nosniff',
};

const collectors = {
  codex: async options => (await import('./collectors/codex.mjs')).collectCodex(options),
  claude: async () => (await import('./collectors/other.mjs')).collectClaude(),
  workbuddy: async () => (await import('./collectors/other.mjs')).collectWorkbuddy(),
};
let groups = {};
let generatedAt = null;
let refreshing = false;
let progress = null;
let pendingAccount;
let latestAccount;
let snapshotState = 'ready';
const dashboardCache = new Map();
const backup = createBackupService({
  folder: path.resolve(root, '..', '备份'),
  projectRoot: path.resolve(root, '..', '..'),
  getDashboard() {
    const { from, to, totals, daily, models, sources, reasoningEfforts } = buildDashboard(groups, { range: 'all' });
    return { generatedAt, from, to, totals, daily, models, sources, reasoningEfforts };
  },
  getLightBackup() {
    return generatedAt ? buildLightBackup(groups, { generatedAt }) : null;
  },
});

function validContribution(row) {
  return row && typeof row.date === 'string' && /^20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(row.date)
    && Number.isSafeInteger(row.total) && row.total >= 0;
}

async function restoreSnapshot() {
  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  try {
    const saved = JSON.parse(await readFile(snapshotFile, 'utf8'));
    if (saved.version === 1 && saved.groups && typeof saved.generatedAt === 'string') {
      groups = saved.groups;
      generatedAt = saved.generatedAt;
    }
  } catch (error) {
    if (error.code !== 'ENOENT') snapshotState = 'read-error';
  }
}

async function runCollector(id) {
  try {
    const result = await collectors[id]({
      dataDir,
      onProgress(update) {
        if (Number.isFinite(update?.processed) && Number.isFinite(update?.total)) {
          progress = { source: id, processed: update.processed, total: update.total };
        }
      },
    });
    const status = result.status;
    const rows = result.rows.filter(validContribution);
    if (status.quality === 'unavailable' && groups[id]?.rows.length) {
      groups[id] = {
        ...groups[id], state: 'stale',
        status: { ...groups[id].status, note: '本次刷新未获取数据，正在显示上次成功读取的记录。' },
      };
    } else {
      groups[id] = { rows, state: status.quality === 'unavailable' ? 'unavailable' : 'ready', status };
    }
  } catch {
    const previous = groups[id];
    groups[id] = {
      rows: previous?.rows ?? [],
      state: previous?.rows.length ? 'stale' : 'unavailable',
      status: {
        quality: previous?.status.quality ?? 'unavailable',
        note: previous?.rows.length ? '本次刷新失败，正在显示上次成功读取的记录。' : '本次读取失败，可尝试刷新。',
      },
    };
  }
  dashboardCache.clear();
}

async function refresh() {
  if (refreshing) return;
  refreshing = true;
  progress = null;
  try {
    await Promise.all(Object.keys(collectors).map(runCollector));
    generatedAt = new Date().toISOString();
    const next = snapshotFile + '.tmp';
    await writeFile(next, JSON.stringify({ version: 1, groups, generatedAt }), { mode: 0o600 });
    await rename(next, snapshotFile);
    snapshotState = 'ready';
  } catch {
    snapshotState = 'write-error';
  } finally {
    progress = null;
    refreshing = false;
  }
}

async function loadAccount() {
  if (latestAccount && Date.now() - latestAccount.time < 60000) return latestAccount.data;
  if (!pendingAccount) {
    pendingAccount = import('./collectors/account.mjs')
      .then(module => module.getCodexAccount())
      .catch(() => ({ available: false, daily: [], lifetime: null, note: '暂时无法读取账号汇总。' }))
      .then(data => {
        if (data.available) latestAccount = { data, time: Date.now() };
        return data;
      })
      .finally(() => { pendingAccount = null; });
  }
  return pendingAccount;
}

function reply(response, status, body) {
  response.writeHead(status, { ...commonHeaders, 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(body));
}

const handleWebConnection = createWebConnection({
  port, commonHeaders, reply,
  startRefresh: refresh,
  getUsage() {
    return {
      refreshing, generatedAt,
      dashboard: !refreshing && generatedAt ? buildDashboard(groups, { range: '30' }) : null,
    };
  },
});

async function route(request, response) {
  const host = request.headers.host;
  const { origin } = request.headers;
  if (!localHosts.has(host)) {
    reply(response, 403, { error: '此服务仅供本机同源访问。' });
    return;
  }
  const url = new URL(request.url, 'http://' + host);
  if ((url.pathname === '/connect-web/usage' || (url.pathname === '/connect-web' && request.method === 'GET'))
    && handleWebConnection(request, response, url)) return;
  if ((origin && origin !== 'http://' + host) || request.headers['sec-fetch-site'] === 'cross-site') {
    reply(response, 403, { error: '此服务仅供本机同源访问。' });
    return;
  }
  if (url.pathname === '/connect-web' && handleWebConnection(request, response, url)) return;
  if (/^\/api\/backup\/[a-z]+$/.test(url.pathname)) {
    await backup(request, response, url, reply, commonHeaders);
    return;
  }
  if (url.pathname === '/api/dashboard' && request.method === 'GET') {
    const range = url.searchParams.get('range') ?? '30';
    const focus = url.searchParams.get('source');
    if (!['7', '30', '90', '365', 'all'].includes(range) || (focus && !Object.hasOwn(collectors, focus))) {
      reply(response, 400, { error: '无效的日期范围或渠道。' });
      return;
    }
    const today = dayOf(new Date());
    const key = JSON.stringify([today, range, focus]);
    if (!dashboardCache.has(key)) {
      if (dashboardCache.size >= 20) dashboardCache.clear();
      dashboardCache.set(key, buildDashboard(groups, { range, focus, today }));
    }
    reply(response, 200, {
      ...dashboardCache.get(key), generatedAt, refreshing, complete: !refreshing && generatedAt !== null,
      progress, snapshotState, viewer,
    });
    return;
  }
  if (url.pathname === '/api/refresh' && request.method === 'POST') {
    void refresh();
    reply(response, 202, { refreshing: true });
    return;
  }
  if (url.pathname === '/api/health' && request.method === 'GET') {
    reply(response, 200, { app: 'my-compute-dashboard' });
    return;
  }
  if (url.pathname === '/api/account' && request.method === 'GET') {
    reply(response, 200, await loadAccount());
    return;
  }
  const file = Object.hasOwn(publicFiles, url.pathname) ? publicFiles[url.pathname] : null;
  if (file && request.method === 'GET') {
    const [filename, type] = file;
    let content;
    try {
      content = await readFile(path.join(root, 'public', filename));
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      reply(response, 404, { error: '页面正在准备或资源不存在。' });
      return;
    }
    response.writeHead(200, { ...commonHeaders, 'Content-Type': type });
    response.end(content);
    return;
  }
  reply(response, 404, { error: '找不到这个页面。' });
}

await restoreSnapshot();
const server = http.createServer((request, response) => {
  void route(request, response).catch(() => {
    if (!response.headersSent) reply(response, 500, { error: '本机服务暂时无法完成请求。' });
    else response.destroy();
  });
});

function openBrowser() {
  execFile('open', [localUrl], () => {});
}

function openRunningInstance() {
  const handle = http.get(localUrl + '/api/health', { timeout: 1000 }, response => {
    let body = '';
    response.setEncoding('utf8');
    response.on('data', chunk => {
      body += chunk;
      if (body.length > 256) handle.destroy();
    });
    response.on('end', () => {
      if (response.statusCode === 200 && body === '{"app":"my-compute-dashboard"}') {
        openBrowser();
      } else {
        console.error('该端口正在使用。可以修改 COMPUTE_DASHBOARD_PORT 后重新启动。');
        process.exitCode = 1;
      }
    });
  });
  handle.on('error', () => {
    console.error('该端口正在使用，无法确认是否为已启动的算力看板。');
    process.exitCode = 1;
  });
  handle.on('timeout', () => handle.destroy(new Error('timeout')));
}

const wantsBrowser = process.argv.includes('--open') && process.platform === 'darwin';
server.on('error', error => {
  if (error.code === 'EADDRINUSE' && wantsBrowser) {
    openRunningInstance();
    return;
  }
  console.error(error.code === 'EADDRINUSE' ? '该端口正在使用。' : '无法在本机启动算力看板。');
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log('我的算力看板 · ' + localUrl);
  if (wantsBrowser) openBrowser();
  void refresh();
});
