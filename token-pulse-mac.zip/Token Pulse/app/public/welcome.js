(() => {
  'use strict';

  const KEYS = {
    completed: 'my-compute-dashboard-welcome-completed',
    name: 'my-compute-dashboard-display-name',
  };
  const memoryProfile = new Map();

  const state = {
    data: null,
    open: false,
    editing: false,
    lastFocused: null,
    selected: 'friend',
    draft: '',
    optionUsername: null,
    refs: null,
  };

  function read(key) {
    if (memoryProfile.has(key)) return memoryProfile.get(key);
    try {
      return window.localStorage.getItem(key) || '';
    } catch (_) {
      return '';
    }
  }

  function write(key, value) {
    memoryProfile.set(key, value);
    try {
      window.localStorage.setItem(key, value);
    } catch (_) {
      /* Browser privacy mode: keep this session usable. */
    }
  }

  function savedName() {
    return read(KEYS.name).trim();
  }
  function isComplete() {
    return read(KEYS.completed) === '1';
  }

  function detectedUsername() {
    const viewer = state.data && state.data.viewer;
    return viewer && typeof viewer.username === 'string' ? viewer.username.trim() : '';
  }

  function sourceNames() {
    const sources = Array.isArray(state.data && state.data.sources) ? state.data.sources : [];
    const names = sources
      .filter(
        (source) => source && source.name && (source.state === 'ready' || Number(source.total) > 0)
      )
      .map((source) => String(source.name).trim())
      .filter(Boolean);
    return [...new Set(names)];
  }

  function platformSentence(names) {
    if (!names.length)
      return state.data?.refreshing ? '正在检测本机使用的工具。' : '暂未检测到本机工具的用量记录。';
    if (names.length === 1) return `检测到你正在使用 ${names[0]}。`;
    return `检测到你正在使用 ${names.slice(0, -1).join('、')} 和 ${names[names.length - 1]}。`;
  }

  function greeting(name) {
    return name ? `你好，${name}` : '设置称呼';
  }

  function syncGreeting() {
    const name = savedName();
    const label = document.getElementById('viewer-greeting');
    const button = document.getElementById('profile-name');
    if (label) label.textContent = greeting(name);
    if (button) {
      button.hidden = false;
      button.setAttribute('aria-label', name ? `当前称呼：${name}，点击修改` : '设置我的称呼');
      if (!button.dataset.welcomeBound) {
        button.dataset.welcomeBound = 'true';
        button.addEventListener('click', () => open(true));
      }
    }
  }

  function option(value, label, detail) {
    const wrapper = document.createElement('label');
    wrapper.className = 'welcome-option';
    wrapper.dataset.value = value;
    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'welcome-name';
    radio.value = value;
    radio.checked = state.selected === value;
    const copy = document.createElement('span');
    copy.className = 'welcome-option__copy';
    const title = document.createElement('strong');
    title.textContent = label;
    const sub = document.createElement('small');
    sub.textContent = detail;
    copy.append(title, sub);
    wrapper.append(radio, copy);
    radio.addEventListener('change', () => {
      state.selected = value;
      updateChoiceVisibility();
    });
    return wrapper;
  }

  function ensure() {
    const mount = document.getElementById('welcome-mount');
    if (!mount) return false;
    if (state.refs) return true;

    const overlay = document.createElement('div');
    overlay.className = 'welcome-overlay';
    overlay.hidden = true;
    const dialog = document.createElement('section');
    dialog.className = 'welcome-dialog';
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-labelledby', 'welcome-title');
    dialog.tabIndex = -1;

    const mast = document.createElement('div');
    mast.className = 'welcome-mast';
    const title = document.createElement('h2');
    title.id = 'welcome-title';
    title.textContent = '亲爱的朋友，欢迎来到你的算力看板';
    const intro = document.createElement('p');
    intro.className = 'welcome-intro';
    intro.textContent = '先用一个称呼，让这块本机看板更像是你的工作台。';
    mast.append(title, intro);

    const detection = document.createElement('div');
    detection.className = 'welcome-detection';
    const status = document.createElement('p');
    status.className = 'welcome-status';
    const chips = document.createElement('div');
    chips.className = 'welcome-platforms';
    chips.setAttribute('aria-label', '检测到的平台');
    detection.append(status, chips);

    const form = document.createElement('form');
    form.className = 'welcome-form';
    const legend = document.createElement('p');
    legend.className = 'welcome-question';
    legend.textContent = '该如何称呼你？';
    const choices = document.createElement('div');
    choices.className = 'welcome-options';
    const custom = document.createElement('label');
    custom.className = 'welcome-option welcome-custom';
    custom.dataset.value = 'custom';
    const customRadio = document.createElement('input');
    customRadio.type = 'radio';
    customRadio.name = 'welcome-name';
    customRadio.value = 'custom';
    const customText = document.createElement('span');
    customText.className = 'welcome-custom__title';
    customText.textContent = '自定义称呼';
    const input = document.createElement('input');
    input.type = 'text';
    input.maxLength = 24;
    input.autocomplete = 'nickname';
    input.placeholder = '例如：林同学';
    input.setAttribute('aria-label', '自定义称呼');
    custom.append(customRadio, customText, input);
    choices.append(custom);
    form.append(legend, choices);

    const privacy = document.createElement('p');
    privacy.className = 'welcome-privacy';
    privacy.textContent = '称呼只保存在这台设备的浏览器中，不会上传。';
    const actions = document.createElement('div');
    actions.className = 'welcome-actions';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'welcome-cancel';
    cancel.textContent = '取消';
    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'welcome-submit';
    submit.textContent = '进入我的看板';
    actions.append(cancel, submit);
    form.append(privacy, actions);
    dialog.append(mast, detection, form);
    overlay.append(dialog);
    mount.replaceChildren(overlay);

    state.refs = {
      overlay,
      dialog,
      status,
      chips,
      choices,
      custom,
      customRadio,
      input,
      cancel,
      submit,
    };
    input.addEventListener('input', () => {
      state.draft = input.value;
    });
    customRadio.addEventListener('change', () => {
      state.selected = 'custom';
      updateChoiceVisibility();
      window.setTimeout(() => input.focus(), 0);
    });
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      let name =
        state.selected === 'custom'
          ? input.value.trim()
          : state.selected === 'username'
            ? detectedUsername()
            : '朋友';
      if (!name) {
        state.selected = 'custom';
        updateChoiceVisibility();
        input.focus();
        return;
      }
      write(KEYS.name, name);
      write(KEYS.completed, '1');
      syncGreeting();
      close();
    });
    cancel.addEventListener('click', () => close());
    overlay.addEventListener('mousedown', (event) => {
      if (event.target === overlay && state.editing) close();
    });
    document.addEventListener('keydown', (event) => {
      if (!state.open) return;
      if (event.key === 'Escape' && state.editing) {
        event.preventDefault();
        close();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = [
        ...dialog.querySelectorAll('button:not([hidden]), input:not([hidden])'),
      ].filter((element) => !element.disabled && element.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
    return true;
  }

  function updateDetection() {
    if (!state.refs) return;
    const names = sourceNames();
    state.refs.status.textContent = platformSentence(names);
    state.refs.chips.replaceChildren();
    names.forEach((name) => {
      const chip = document.createElement('span');
      chip.textContent = name;
      state.refs.chips.append(chip);
    });
  }

  function updateOptions() {
    if (!state.refs) return;
    const { choices, custom } = state.refs;
    const username = detectedUsername();
    if (
      state.optionUsername === username &&
      choices.querySelector('.welcome-option:not(.welcome-custom)')
    ) {
      updateChoiceVisibility();
      return;
    }
    const focusedValue =
      document.activeElement && document.activeElement.name === 'welcome-name'
        ? document.activeElement.value
        : '';
    const previous = choices.querySelectorAll('.welcome-option');
    previous.forEach((element) => {
      if (element !== custom) element.remove();
    });
    if (username)
      choices.insertBefore(option('username', username, '检测到的本机登录名称'), custom);
    choices.insertBefore(option('friend', '朋友', '简洁、亲切的默认称呼'), custom);
    state.optionUsername = username;
    updateChoiceVisibility();
    if (focusedValue) {
      const replacement = choices.querySelector(`input[value="${focusedValue}"]`);
      if (replacement) replacement.focus();
    }
  }

  function updateChoiceVisibility() {
    if (!state.refs) return;
    const { choices, custom, customRadio, input } = state.refs;
    choices.querySelectorAll('.welcome-option').forEach((element) => {
      element.classList.toggle('is-selected', element.dataset.value === state.selected);
      const radio = element.querySelector('input');
      if (radio) radio.checked = element.dataset.value === state.selected;
    });
    custom.classList.toggle('is-selected', state.selected === 'custom');
    customRadio.checked = state.selected === 'custom';
    input.hidden = state.selected !== 'custom';
    if (!input.hidden) input.value = state.draft;
  }

  function open(editing) {
    if (!ensure()) return;
    state.editing = Boolean(editing);
    state.lastFocused = document.activeElement;
    const old = savedName();
    const username = detectedUsername();
    state.draft = state.editing && old ? old : '';
    state.selected =
      state.editing && old === username
        ? 'username'
        : state.editing && old && old !== '朋友'
          ? 'custom'
          : 'friend';
    updateDetection();
    updateOptions();
    state.refs.cancel.hidden = !state.editing;
    state.refs.submit.textContent = state.editing ? '保存称呼' : '进入我的看板';
    state.refs.overlay.hidden = false;
    state.open = true;
    document.body.classList.add('welcome-open');
    window.setTimeout(() => {
      const target =
        state.selected === 'custom'
          ? state.refs.input
          : state.refs.dialog.querySelector('input[type="radio"]');
      (target || state.refs.dialog).focus();
    }, 0);
  }

  function close() {
    if (!state.refs || !state.open) return;
    state.refs.overlay.hidden = true;
    state.open = false;
    document.body.classList.remove('welcome-open');
    if (state.editing && state.lastFocused && typeof state.lastFocused.focus === 'function')
      state.lastFocused.focus();
  }

  window.renderWelcome = function renderWelcome(data) {
    state.data = data || {};
    if (!ensure()) return;
    syncGreeting();
    updateDetection();
    if (state.open) {
      updateOptions();
      return;
    }
    if (!isComplete()) open(false);
  };
})();
