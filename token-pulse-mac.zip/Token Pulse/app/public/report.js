(() => {
  const state = { data: null, page: 0, pageSize: 8 };
  const $ = selector => document.querySelector(selector);
  const number = value => Number.isFinite(Number(value)) ? Number(value) : 0;
  const fmt = value => window.computeUnits?.format?.(value) ?? '—';
  const clear = element => { while (element.firstChild) element.removeChild(element.firstChild); };
  const el = (tag, text, className) => {
    const element = document.createElement(tag);
    if (text !== undefined) element.textContent = text;
    if (className) element.className = className;
    return element;
  };
  const formatYuan = value => value >= 10000 ? `¥${(value / 10000).toFixed(1)}万` : `¥${Math.round(value).toLocaleString('zh-CN')}`;

  // 与 TokenBurn 的 E1–E11 段位门槛保持一致；只把它作为累计记录的展示标签。
  const ranks = [
    { min: 100_000_000_000, badge: 'E11', title: '奇点执政架构师' },
    { min: 50_000_000_000, badge: 'E10', title: '星系级算力总督' },
    { min: 10_000_000_000, badge: 'E9', title: '超算集群总工程师' },
    { min: 2_000_000_000, badge: 'E8', title: '资深首席架构师' },
    { min: 500_000_000, badge: 'E7', title: '首席工程架构师' },
    { min: 100_000_000, badge: 'E6', title: '资深主任架构师' },
    { min: 50_000_000, badge: 'E5', title: '核心参谋工程师' },
    { min: 10_000_000, badge: 'E4', title: '高级系统工程师' },
    { min: 1_000_000, badge: 'E3', title: '专职研发工程师' },
    { min: 100_000, badge: 'E2', title: '初阶工程专家' },
    { min: 0, badge: 'E1', title: '工程探索成员' },
  ];

  function rank(total) {
    const index = ranks.findIndex(item => total >= item.min);
    const current = ranks[index === -1 ? ranks.length - 1 : index];
    const next = index > 0 ? ranks[index - 1] : null;
    const progress = next ? Math.min(100, Math.max(0, ((total - current.min) / (next.min - current.min)) * 100)) : 100;
    return { ...current, next, progress };
  }

  function ratio(value, total) {
    return total > 0 ? `${((value / total) * 100).toFixed(1)}%` : '—';
  }

  function rangeForRank(grade) {
    return grade.next ? `${fmt(grade.min)} 至低于 ${fmt(grade.next.min)} Token` : `≥ ${fmt(grade.min)} Token`;
  }

  function scopedSources(data) {
    const sources = data.sources || [];
    return data.focus ? sources.filter(source => source.id === data.focus) : sources;
  }

  function milestone(label, reached, text) {
    const box = el('div', undefined, `report-milestone${reached ? ' is-reached' : ''}`);
    box.append(el('span', reached ? '已达成' : '进行中', 'report-state'), el('b', label), el('small', text));
    return box;
  }

  function renderSummary(data) {
    const target = $('#report-summary');
    if (!target) return;
    const formulaOpen = target.querySelector('.report-formula')?.open === true;
    clear(target);
    const totals = data.totals || {};
    const total = number(totals.total);
    const lifetimeTotal = Number.isFinite(data.lifetimeTotal) ? Number(data.lifetimeTotal) : total;
    const hasPairedSplit = Number.isFinite(totals.splitInput) && Number.isFinite(totals.splitOutput);
    const input = hasPairedSplit ? totals.splitInput : null;
    const output = hasPairedSplit ? totals.splitOutput : null;
    const cached = hasPairedSplit && Number.isFinite(totals.splitCached) ? Number(totals.splitCached) : null;
    const splitBase = input === null || output === null ? 0 : input + output;
    const splitCoverage = number(totals.knownSplitTotal);
    const equivalentLines = output === null ? null : Math.floor(output / 120);
    const equivalentHours = equivalentLines === null ? null : Math.round(equivalentLines / 80);
    const equivalentDays = equivalentHours === null ? null : (equivalentHours / 8).toFixed(1);
    const equivalentMonths = equivalentHours === null ? null : (equivalentHours / 174).toFixed(1);
    const equivalentYears = equivalentHours === null ? null : (equivalentHours / 2088).toFixed(2);
    const equivalentProjects = equivalentLines === null ? null : (equivalentLines / 25000).toFixed(1);
    const hypotheticalValue = equivalentHours === null ? null : equivalentHours * 100;
    const grade = rank(lifetimeTotal);
    const sourceCount = scopedSources(data).filter(source => number(source.total) > 0).length;
    const section = el('section', undefined, 'report-summary-grid');
    const gradeCard = el('article', undefined, 'report-card report-grade');
    const rankHead = el('div', undefined, 'report-rank-head');
    rankHead.append(el('span', grade.badge, 'report-rank-badge'), el('span', '累计段位', 'report-rank-label'));
    gradeCard.append(rankHead, el('h2', grade.title));
    const gradeMetric = el('div', undefined, 'report-grade-metric');
    gradeMetric.append(el('b', fmt(lifetimeTotal)), el('span', '保留历史累计 Token'));
    gradeCard.append(gradeMetric);
    const rankRange = el('div', undefined, 'report-rank-progress');
    rankRange.append(el('span', `当前区间：${rangeForRank(grade)}`));
    if (grade.next) {
      const progressTrack = el('div', undefined, 'report-progress-track');
      const progressFill = el('i', undefined, 'report-progress-fill');
      progressFill.style.width = `${grade.progress.toFixed(1)}%`;
      progressTrack.append(progressFill);
      rankRange.append(progressTrack, el('small', `距离 ${grade.next.badge} ${grade.next.title}：${fmt(Math.max(0, grade.next.min - lifetimeTotal))}`));
    } else {
      rankRange.append(el('small', '已处于当前体系最高段位'));
    }
    gradeCard.append(rankRange);

    const estimateCard = el('article', undefined, 'report-card report-equivalence');
    estimateCard.append(el('h2', '战力等效换算'), el('p', '基于本期记录的输出 Token 做情景估算。', 'report-copy'));
    const metricGrid = el('div', undefined, 'report-equivalence-metrics');
    [
      ['代码行当量', equivalentLines === null ? '—' : fmt(equivalentLines),
        equivalentProjects === null ? '' : `约 ${equivalentProjects} 个项目当量`],
      ['研发工时当量', equivalentHours === null ? '—' : `${fmt(equivalentHours)} h`,
        equivalentHours === null ? '' : `${equivalentDays} 工作日 · ${equivalentMonths} 人月 · ${equivalentYears} 人年`],
      ['参考人力价值', hypotheticalValue === null ? '—' : formatYuan(hypotheticalValue),
        hypotheticalValue === null ? '' : '按 ¥100 / 小时换算'],
    ].forEach(([label, value, breakdown]) => {
      const item = el('div');
      item.append(el('span', label), el('b', value));
      if (breakdown) item.append(el('small', breakdown));
      metricGrid.append(item);
    });
    estimateCard.append(metricGrid);
    const formula = el('details', undefined, 'report-formula');
    formula.open = formulaOpen;
    formula.append(el('summary', '展开四步计算与数据口径'));
    const formulaIntro = el('p', hasPairedSplit
      ? `同时记录了输入和输出的用量为 ${fmt(splitCoverage)}，占本期总量 ${ratio(splitCoverage, total)}。换算以其中实际记录的输出为基数。`
      : '当前范围缺少完整的输入和输出记录，暂无法换算。');
    const steps = el('div', undefined, 'report-formula-steps');
    const makeStep = (no, title, detail) => {
      const step = el('article', undefined, 'report-formula-step');
      step.append(el('span', String(no).padStart(2, '0'), 'report-step-no'), el('b', title), el('p', detail));
      return step;
    };
    steps.append(
      makeStep(1, '观察到的输入 / 输出', input === null || output === null
        ? '输入与输出拆分尚不完整，比例不展示。'
        : `输入 ${fmt(input)}（${ratio(input, splitBase)}） · 输出 ${fmt(output)}（${ratio(output, splitBase)}）${cached === null ? '' : ` · 输入中含缓存读取 ${fmt(cached)}`}。`),
      makeStep(2, '输出换算为代码行当量', output === null ? '缺少可用输出 token，暂不换算。' : `${fmt(output)} ÷ 120 = ${fmt(equivalentLines)} 行；${fmt(equivalentLines)} ÷ 25,000 = ${equivalentProjects} 个项目当量。`),
      makeStep(3, '代码行当量换算为研发时间', equivalentHours === null ? '缺少上一步的输出数据。' : `${fmt(equivalentLines)} ÷ 80 = ${fmt(equivalentHours)} 小时；÷ 8 = ${equivalentDays} 工作日；÷ 174 = ${equivalentMonths} 人月；÷ 2,088 = ${equivalentYears} 人年。`),
      makeStep(4, '参考人力价值', hypotheticalValue === null ? '缺少上一步的工时数据。' : `${fmt(equivalentHours)} 小时 × ¥100 / 小时 = ${formatYuan(hypotheticalValue)}。`),
    );
    formula.append(formulaIntro, steps, el('p', '假设固定为：120 输出 Token / 行、80 行 / 工时、8 小时 / 工作日、174 小时 / 人月、2,088 小时 / 人年、25,000 行 / 项目、¥100 / 小时。它们是透明的情景参数，不代表实际代码、节省工时、项目交付或账单金额。', 'report-formula-note'));
    estimateCard.append(formula);

    const milestoneCard = el('article', undefined, 'report-card report-milestones');
    milestoneCard.append(el('p', '里程碑', 'report-kicker'), el('h2', '本期记录'));
    const wall = el('div', undefined, 'report-milestone-wall');
    wall.append(
      milestone(fmt(1e6) + ' Token', total >= 1e6, `${fmt(total)} / ${fmt(1e6)}`),
      milestone('活跃 7 天', number(totals.activeDays) >= 7, `${number(totals.activeDays)} 天`),
      milestone('10 个会话', number(totals.sessions) >= 10, `${number(totals.sessions)} 个`),
      milestone('多渠道', sourceCount >= 2, `${sourceCount} 个渠道`),
    );
    milestoneCard.append(wall);
    section.append(gradeCard, estimateCard, milestoneCard);
    target.append(section);
  }

  function currentSessions() {
    return Array.isArray(state.data?.sessions) ? state.data.sessions : [];
  }

  function renderLedger() {
    const target = $('#report-details');
    if (!target) return;
    clear(target);
    const sessions = currentSessions();
    const section = el('section', undefined, 'report-detail-grid');
    const ledger = el('article', undefined, 'report-card report-ledger');
    const heading = el('div', undefined, 'report-heading');
    const titleGroup = el('div');
    titleGroup.append(el('p', '活动流水', 'report-kicker'), el('h2', '项目会话流水'));
    heading.append(titleGroup, el('span', sessions.length ? `展示 ${sessions.length} 个会话` : '当前范围暂无会话明细', 'report-muted'));
    ledger.append(heading);
    if (!sessions.length) {
      ledger.append(el('p', '当前统计范围没有可展示的项目会话记录。', 'report-empty'));
    } else {
      const tableWrap = el('div', undefined, 'report-table-wrap');
      const table = el('table', undefined, 'report-table');
      const head = el('thead');
      const headRow = el('tr');
      ['项目', '渠道', '日期', '模型', '推理强度', 'Token'].forEach(label => headRow.append(el('th', label)));
      head.append(headRow);
      const body = el('tbody');
      const pageCount = Math.max(1, Math.ceil(sessions.length / state.pageSize));
      state.page = Math.min(state.page, pageCount - 1);
      sessions.slice(state.page * state.pageSize, (state.page + 1) * state.pageSize).forEach(session => {
        const row = el('tr');
        const sourceName = (state.data.sources || []).find(source => source.id === session.source)?.name;
        const dates = session.firstDate === session.lastDate ? session.firstDate
          : [session.firstDate, session.lastDate].filter(Boolean).join(' 至 ');
        const efforts = session.reasoningEfforts || [];
        const effortTotal = efforts.reduce((sum, entry) => sum + entry.total, 0);
        const effortLabels = efforts.map(entry => entry.effort);
        const setting = session.reasoningSetting;
        if (efforts.length && effortTotal < number(session.total)) effortLabels.push('未记录');
        if (setting) {
          const label = setting === 'enabled' ? '已开启' : setting === 'disabled' ? '已关闭' : setting;
          effortLabels.push(label + '（会话设置）');
        }
        [
          session.project || '未记录项目',
          sourceName || '未知渠道',
          dates || '—',
          session.model || '未标注模型',
          effortLabels.join(' / ') || '未记录',
          fmt(session.total),
        ].forEach(value => row.append(el('td', value)));
        body.append(row);
      });
      table.append(head, body);
      tableWrap.append(table);
      ledger.append(tableWrap);
      if (pageCount > 1) {
        const pager = el('div', undefined, 'report-pager');
        const previous = el('button', '上一页');
        previous.type = 'button';
        previous.dataset.reportAction = 'previous';
        previous.disabled = state.page === 0;
        const next = el('button', '下一页');
        next.type = 'button';
        next.dataset.reportAction = 'next';
        next.disabled = state.page >= pageCount - 1;
        pager.append(previous, el('span', `${state.page + 1} / ${pageCount}`), next);
        ledger.append(pager);
      }
    }

    const tools = el('article', undefined, 'report-card report-exports');
    tools.append(el('p', '本地战报', 'report-kicker'), el('h2', '导出本期摘要'), el('p', '导出内容只有当前筛选范围的聚合数据，不含项目路径、提示词、原始会话或响应标识。', 'report-copy'));
    const buttonArea = el('div', undefined, 'report-actions');
    [['poster', '下载战报 PNG'], ['copy-poster', '复制战报 PNG'], ['json', '下载摘要 JSON'], ['csv', '下载每日 CSV']].forEach(([action, label]) => {
      const button = el('button', label);
      button.type = 'button';
      button.dataset.reportAction = action;
      buttonArea.append(button);
    });
    tools.append(buttonArea);
    section.append(ledger, tools);
    target.append(section);
  }

  function download(filename, blob) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function publicSnapshot() {
    const data = state.data || {};
    return {
      title: '我的算力看板摘要',
      range: { from: data.from, to: data.to },
      generatedAt: data.generatedAt || null,
      totals: data.totals || {},
      focus: data.focus || null,
      sources: scopedSources(data).map(({
        id, name, quality, note, total, input, cached, output, sessions, activeDays, coverageFrom, coverageTo,
        reasoningEfforts = [], reasoningSettings = [], reasoningSettingsSupported,
      }) => ({
        id, name, quality, note, total, input, cached, output, sessions, activeDays, coverageFrom, coverageTo,
        reasoningEfforts, reasoningSettings, reasoningSettingsSupported,
      })),
      daily: (data.daily || []).map(({ date, total, codex, claude, workbuddy }) => ({ date, total, codex, claude, workbuddy })),
      reasoningEfforts: data.reasoningEfforts || [],
      models: (data.models || []).map(({
        source, name, total, sessions, reasoningEfforts = [], reasoningSettings = [], reasoningSettingsSupported,
      }) => ({ source, name, total, sessions, reasoningEfforts, reasoningSettings, reasoningSettingsSupported })),
    };
  }

  function posterCanvas() {
    const data = state.data || {};
    const totals = data.totals || {};
    const canvas = document.createElement('canvas');
    canvas.width = 1600;
    canvas.height = 900;
    const context = canvas.getContext('2d');
    const gradient = context.createLinearGradient(0, 0, 1600, 900);
    gradient.addColorStop(0, '#07111f');
    gradient.addColorStop(1, '#123957');
    context.fillStyle = gradient;
    context.fillRect(0, 0, canvas.width, canvas.height);
    [['#55e6df', 96, 128], ['#f9b65c', 132, 92], ['#ae9cff', 168, 56]].forEach(([color, y, h], index) => {
      context.fillStyle = color;
      context.fillRect(92 + index * 26, y, 12, h);
    });
    context.fillStyle = '#8ea4bc';
    context.font = '600 28px system-ui, sans-serif';
    context.fillText('MY COMPUTE DASHBOARD', 92, 300);
    context.fillStyle = '#eaf3ff';
    context.font = '700 72px system-ui, sans-serif';
    context.fillText('我的算力看板', 92, 390);
    context.fillStyle = '#55e6df';
    context.font = '700 160px system-ui, sans-serif';
    context.fillText(fmt(totals.total), 92, 590);
    context.fillStyle = '#b6c8d8';
    context.font = '500 34px system-ui, sans-serif';
    context.fillText('Token · 当前筛选范围', 96, 648);
    const channels = scopedSources(data).filter(source => number(source.total) > 0).map(source => source.name || source.id).join(' · ') || '无可用渠道';
    context.fillStyle = '#54738c';
    context.fillRect(92, 718, 1416, 1);
    context.fillStyle = '#eaf3ff';
    [`活跃 ${number(totals.activeDays)} 天`, `会话 ${number(totals.sessions)} 个`, `${data.from || '—'} 至 ${data.to || '—'}`].forEach((fact, index) => context.fillText(fact, 92 + index * 410, 785));
    context.fillStyle = '#8ea4bc';
    context.font = '500 22px system-ui, sans-serif';
    context.fillText(`渠道：${channels} · 本地聚合统计`, 92, 844);
    return canvas;
  }

  function makePoster() {
    const data = state.data || {};
    const canvas = posterCanvas();
    canvas.toBlob(blob => {
      if (blob) download(`我的算力战报_${data.from || '本期'}_${data.to || '当前'}.png`, blob);
    }, 'image/png');
  }

  async function copyPoster(button) {
    if (!navigator.clipboard?.write || !window.ClipboardItem) {
      button.textContent = '此浏览器不支持复制';
      setTimeout(() => { button.textContent = '复制战报 PNG'; }, 1800);
      return;
    }
    const canvas = posterCanvas();
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    if (!blob) return;
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      button.textContent = '已复制战报 PNG';
    } catch {
      button.textContent = '复制未完成';
    }
    setTimeout(() => { button.textContent = '复制战报 PNG'; }, 1800);
  }

  function exportJson() {
    download(`我的算力摘要_${state.data?.from || '本期'}_${state.data?.to || '当前'}.json`, new Blob([JSON.stringify(publicSnapshot(), null, 2)], { type: 'application/json;charset=utf-8' }));
  }

  function exportCsv() {
    const columns = ['date', 'total', 'codex', 'claude', 'workbuddy'];
    const body = [columns.join(',')].concat(publicSnapshot().daily.map(row => columns.map(column => row[column] ?? '').join(','))).join('\n');
    download(`我的算力每日摘要_${state.data?.from || '本期'}_${state.data?.to || '当前'}.csv`, new Blob(['\uFEFF' + body], { type: 'text/csv;charset=utf-8' }));
  }

  document.addEventListener('click', event => {
    const button = event.target.closest('[data-report-action]');
    if (!button) return;
    if (button.dataset.reportAction === 'previous') { state.page = Math.max(0, state.page - 1); renderLedger(); }
    else if (button.dataset.reportAction === 'next') { state.page += 1; renderLedger(); }
    else if (button.dataset.reportAction === 'poster') makePoster();
    else if (button.dataset.reportAction === 'copy-poster') void copyPoster(button);
    else if (button.dataset.reportAction === 'json') exportJson();
    else if (button.dataset.reportAction === 'csv') exportCsv();
  });

  window.renderReport = data => {
    state.data = data;
    state.page = 0;
    renderSummary(data);
    renderLedger();
  };
})();
