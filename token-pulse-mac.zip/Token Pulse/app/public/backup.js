(() => {
  'use strict';

  const state = {
    mode: 'light',
    estimate: null,
    estimateRequest: 0,
    selectedProjects: new Set(),
    initializedModes: new Set(),
    submitting: false,
    destination: null,
    choosingDestination: false,
    importing: false,
    recentRequest: 0,
    polling: false,
    loadingEstimate: false,
    selectedSources: new Set(),
    selectedFiles: new Set(),
    jobId: '',
    timer: 0,
    dialog: null,
    refs: {},
  };
  const $ = (id) => document.getElementById(id);
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
  const bytes = (value) => {
    const n = num(value);
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let x = n;
    while (x >= 1024 && i < units.length - 1) {
      x /= 1024;
      i += 1;
    }
    return `${x >= 10 || i === 0 ? x.toFixed(0) : x.toFixed(1)} ${units[i]}`;
  };
  const sourceSessions = (source) =>
    num(
      source && (source.sessionCount ?? source.candidateCount ?? source.candidates ?? source.count)
    );
  const sourceBytes = (source) =>
    num(source && (source.bytes ?? source.estimatedBytes ?? source.estimated));
  const modeName = (mode) => ({ light: '轻量备份', full: '完整备份' }[mode] || '备份包');
  const tokenCount = (value) => num(value).toLocaleString('zh-CN');
  const dateRange = ({ from, to }) => [from, to].filter(Boolean).join(' 至 ') || '日期未知';
  const node = (tag, text, cls) => {
    const n = document.createElement(tag);
    if (text !== undefined) n.textContent = text;
    if (cls) n.className = cls;
    return n;
  };
  const clear = (n) => {
    while (n.firstChild) n.removeChild(n.firstChild);
  };
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      ...options,
      headers: { 'content-type': 'application/json', ...(options.headers || {}) },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || data.message || '本机服务暂时无法完成此操作');
    return data;
  };

  function ensure() {
    if (state.dialog) return true;
    const mount = $('backup-mount');
    if (!mount) return false;
    const dialog = document.createElement('dialog');
    dialog.className = 'backup-dialog';
    dialog.setAttribute('aria-labelledby', 'backup-title');
    const shell = node('div', undefined, 'backup-shell');
    const head = node('header', undefined, 'backup-head');
    const heading = node('div');
    heading.append(
      node('p', 'LOCAL ARCHIVE', 'backup-eyebrow'),
      node('h2', '历史与备份', 'backup-title')
    );
    heading.lastChild.id = 'backup-title';
    const close = node('button', '关闭', 'backup-close');
    close.type = 'button';
    close.setAttribute('aria-label', '关闭历史与备份');
    close.addEventListener('click', () => dialog.close());
    head.append(heading, close);
    const intro = node(
      'p',
      '选择要保存的内容、位置和保护方式。',
      'backup-intro'
    );
    const status = node('p', '正在读取本机备份清单…', 'backup-status');
    status.setAttribute('role', 'status');
    const modes = node('div', undefined, 'backup-modes');
    modes.setAttribute('role', 'group');
    modes.setAttribute('aria-label', '备份方式');
    const modeButtons = {};
    for (const mode of ['light', 'full']) {
      const button = node('button', modeName(mode), 'button button--small');
      button.type = 'button';
      button.addEventListener('click', () => {
        if (state.mode !== mode || (!state.estimate && !state.loadingEstimate)) loadEstimate(mode);
      });
      modes.append(button);
      modeButtons[mode] = button;
    }
    const importBar = node('div', undefined, 'backup-import-bar');
    const importButton = node('button', '导入备份', 'button button--small');
    importButton.type = 'button';
    const importInput = document.createElement('input');
    importInput.type = 'file';
    importInput.accept = '.compute-backup';
    importInput.hidden = true;
    importInput.addEventListener('change', importBackup);
    importButton.addEventListener('click', () => importInput.click());
    const importHelp = node('details', undefined, 'backup-import-help');
    const importSteps = node('ol');
    for (const text of [
      '换机后，在新电脑的智脉中打开「历史与备份」，点击「导入备份」，选中原电脑保存的 .compute-backup 文件。',
      '导入会把备份包复制到新电脑的默认备份文件夹。导入完成后，在「已有本机备份」点击「查看」。有密码的包使用原密码，无密码的包可直接查看。',
      '轻量备份用于查阅项目、模型、推理强度和 Token 汇总。完整备份可查阅已保存的会话，并逐个恢复已备份的附件。导入内容在备份查看器中查阅。',
    ]) importSteps.append(node('li', text));
    importHelp.append(node('summary', '导入说明'), importSteps);
    const importStatus = node('p', '', 'backup-help backup-import-status');
    importStatus.setAttribute('role', 'status');
    importBar.append(importButton, importInput, importHelp, importStatus);
    const body = node('div', undefined, 'backup-body');
    const light = node('section', undefined, 'backup-section');
    const lightHead = node('div', undefined, 'backup-section-head');
    const lightTitle = node('div');
    lightTitle.append(
      node('h3', '选择项目'),
      node('p', '保存项目使用过的渠道、模型、推理强度和 Token 用量。', 'backup-help')
    );
    const lightActions = node('div', undefined, 'backup-filters');
    const lightAll = node('button', '选中全部项目', 'button button--small');
    const lightNone = node('button', '清空项目选择', 'button button--small');
    for (const button of [lightAll, lightNone]) button.type = 'button';
    lightAll.addEventListener('click', () => chooseProjects(true));
    lightNone.addEventListener('click', () => chooseProjects(false));
    lightActions.append(lightAll, lightNone);
    lightHead.append(lightTitle, lightActions);
    const lightSearchBar = node('div', undefined, 'backup-light-search');
    const lightSearch = node('input', undefined, 'backup-view-filter');
    lightSearch.type = 'search';
    lightSearch.placeholder = '搜索项目';
    lightSearch.setAttribute('aria-label', '搜索项目');
    lightSearch.addEventListener('input', renderLightProjects);
    const lightCount = node('p', '', 'backup-help');
    lightCount.setAttribute('aria-live', 'polite');
    lightSearchBar.append(lightSearch, lightCount);
    const lightList = node('div', undefined, 'backup-light-projects');
    light.append(lightHead, lightSearchBar, lightList);
    const sources = node('section', undefined, 'backup-section');
    sources.append(
      node('h3', '可读取的会话内容'),
      node('p', '默认选中可用渠道。会话和下方项目文件独立选择。', 'backup-help')
    );
    const sourceList = node('div', undefined, 'backup-source-list');
    sources.append(sourceList);
    const files = node('section', undefined, 'backup-section');
    const filesHead = node('div', undefined, 'backup-section-head');
    filesHead.append(node('div', undefined, 'backup-section-title'));
    filesHead.firstChild.append(
      node('h3', '可选附件与项目文件'),
      node('p', '全部项目操作覆盖所有可选项目文件，包括筛选隐藏的文件。', 'backup-help')
    );
    const filters = node('div', undefined, 'backup-filters');
    const categoryFilter = document.createElement('select');
    categoryFilter.className = 'backup-project-filter';
    categoryFilter.setAttribute('aria-label', '按类别筛选附件');
    categoryFilter.addEventListener('change', renderFiles);
    const projectFilter = document.createElement('select');
    projectFilter.className = 'backup-project-filter';
    projectFilter.setAttribute('aria-label', '按项目筛选附件');
    projectFilter.addEventListener('change', renderFiles);
    const bulk = node('button', '选择当前筛选', 'button button--small backup-bulk');
    bulk.type = 'button';
    bulk.addEventListener('click', () => {
      const filesInScope = filteredFiles();
      const shouldSelect = filesInScope.some(file => !state.selectedFiles.has(file.id));
      for (const file of filesInScope) shouldSelect ? state.selectedFiles.add(file.id) : state.selectedFiles.delete(file.id);
      renderFiles(); updateSummary();
    });
    filters.append(categoryFilter, projectFilter, bulk);
    filesHead.append(filters);
    const fullActions = node('div', undefined, 'backup-filters backup-full-actions');
    const fullAll = node('button', '选中全部项目', 'button button--small');
    const fullNone = node('button', '清空选中项目', 'button button--small');
    for (const button of [fullAll, fullNone]) button.type = 'button';
    fullAll.addEventListener('click', () => chooseFiles(true));
    fullNone.addEventListener('click', () => chooseFiles(false));
    fullActions.append(fullAll, fullNone);
    const fileList = node('div', undefined, 'backup-file-list');
    files.append(filesHead, fullActions, fileList);
    const summary = node('section', undefined, 'backup-summary');
    const summaryText = node('div');
    const summaryStrong = node('strong', '—');
    const summaryNote = node('p', '', 'backup-summary-note');
    summaryText.append(summaryStrong, summaryNote);
    summary.append(summaryText);
    const destinationSection = node('section', undefined, 'backup-section backup-destination-section');
    const destinationTitle = node('h3', '保存位置');
    const destination = node('p', '', 'backup-help backup-location');
    const chooseLocation = node('button', '选择保存位置', 'button button--small');
    const defaultLocation = node('button', '使用默认位置', 'button button--small');
    chooseLocation.type = defaultLocation.type = 'button';
    chooseLocation.addEventListener('click', chooseDestination);
    defaultLocation.addEventListener('click', () => {
      state.destination = null;
      state.refs.destinationStatus.textContent = '';
      updateSummary();
      loadRecent();
    });
    const locationActions = node('div', undefined, 'backup-filters');
    locationActions.append(chooseLocation, defaultLocation);
    const destinationStatus = node('p', '', 'backup-help');
    destinationStatus.setAttribute('role', 'status');
    destinationSection.append(destinationTitle, destination, locationActions, destinationStatus);
    const form = document.createElement('form');
    form.className = 'backup-form';
    form.noValidate = true;
    const password = document.createElement('input');
    password.id = 'backup-password';
    password.type = 'password';
    password.autocomplete = 'new-password';
    password.minLength = 10;
    password.required = true;
    password.placeholder = '至少 10 个字符';
    const confirmPassword = document.createElement('input');
    confirmPassword.type = 'password';
    confirmPassword.autocomplete = 'new-password';
    confirmPassword.required = true;
    confirmPassword.placeholder = '再次输入密码';
    const passwords = node('div', undefined, 'backup-passwords');
    const makeField = (label, input) => {
      const l = node('label', label);
      l.append(input);
      return l;
    };
    passwords.append(makeField('加密密码', password), makeField('确认密码', confirmPassword));
    const start = node('button', '确认并开始备份', 'button backup-start');
    start.type = 'submit';
    const protectionLabel = node('label', '密码保护', 'backup-protection');
    const protection = document.createElement('select');
    protection.setAttribute('aria-label', '密码保护');
    protection.append(new Option('使用密码', 'password'), new Option('无密码', 'plain'));
    protectionLabel.append(protection);
    const protectionNote = node('p', '', 'backup-help');
    protection.addEventListener('change', syncProtection);
    form.append(protectionLabel, protectionNote, passwords, start);
    const progress = node('div', undefined, 'backup-progress');
    progress.hidden = true;
    const progressText = node('p', '', 'backup-progress-text');
    const meter = document.createElement('progress');
    meter.max = 1;
    meter.value = 0;
    progress.append(progressText, meter);
    const recent = node('section', undefined, 'backup-section backup-recent');
    recent.append(
      node('h3', '已有本机备份'),
      node(
        'p',
        '这里列出默认位置和当前选择位置中的备份。',
        'backup-help'
      )
    );
    const recentList = node('div', undefined, 'backup-recent-list');
    recent.append(recentList);
    body.append(destinationSection, light, sources, files, summary, form, progress, recent);
    shell.append(head, importBar, modes, intro, status, body);
    dialog.append(shell);
    mount.append(dialog);
    dialog.addEventListener('close', () => {
      state.estimateRequest++;
      window.clearTimeout(state.timer);
      state.timer = 0;
      state.refs.password.value = '';
      state.refs.confirmPassword.value = '';
    });
    dialog.addEventListener('cancel', () => {
      window.clearTimeout(state.timer);
    });
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      startBackup();
    });
    state.dialog = dialog;
    state.refs = {
      intro,
      importButton,
      importInput,
      importStatus,
      modeButtons,
      light,
      lightList,
      lightSearch,
      lightCount,
      lightAll,
      lightNone,
      sources,
      files,
      status,
      sourceList,
      fileList,
      categoryFilter,
      projectFilter,
      bulk,
      fullAll,
      fullNone,
      summaryStrong,
      summaryNote,
      destination,
      chooseLocation,
      defaultLocation,
      destinationStatus,
      protection,
      protectionNote,
      passwords,
      password,
      confirmPassword,
      progress,
      progressText,
      meter,
      recentList,
      start,
    };
    syncProtection();
    return true;
  }

  function syncProtection() {
    const { protection, passwords, password, confirmPassword, protectionNote } = state.refs;
    const encrypted = protection.value !== 'plain';
    passwords.hidden = password.disabled = confirmPassword.disabled = !encrypted;
    if (!encrypted) {
      password.value = '';
      confirmPassword.value = '';
    }
    protectionNote.textContent = encrypted
      ? '打开备份时需要原密码。请妥善保存密码。'
      : '能访问此备份文件的人可以直接读取内容。';
  }

  async function chooseDestination() {
    if (state.choosingDestination || state.submitting || state.jobId) return;
    state.choosingDestination = true;
    state.refs.destinationStatus.textContent = '请在系统窗口中选择保存文件夹。';
    updateSummary();
    try {
      const { destination } = await api('/api/backup/destination', {
        method: 'POST', body: '{}',
      });
      if (destination) {
        state.destination = destination;
        loadRecent();
      }
      state.refs.destinationStatus.textContent = '';
    } catch (error) {
      state.refs.destinationStatus.textContent = error.message;
    } finally {
      state.choosingDestination = false;
      updateSummary();
    }
  }

  async function importBackup() {
    const { importButton, importInput, importStatus } = state.refs;
    const file = importInput.files?.[0];
    importInput.value = '';
    if (!file || state.importing || state.submitting || state.jobId) return;
    if (!file.name.toLowerCase().endsWith('.compute-backup')) {
      importStatus.textContent = '请选择 .compute-backup 文件。';
      return;
    }
    state.importing = importButton.disabled = true;
    importStatus.textContent = '正在导入备份…';
    updateSummary();
    try {
      const { backup, alreadyPresent } = await api('/api/backup/import', {
        method: 'POST',
        headers: {
          'content-type': 'application/octet-stream',
          'X-Backup-Name': encodeURIComponent(file.name),
        },
        body: file,
      });
      importStatus.textContent = alreadyPresent
        ? '此备份已在列表中，可在「已有本机备份」查看。'
        : `已导入 ${backup?.name || file.name}，可在「已有本机备份」查看。`;
      loadRecent();
    } catch (error) {
      importStatus.textContent = error.message;
    } finally {
      state.importing = importButton.disabled = false;
      updateSummary();
    }
  }

  function chooseFiles(all) {
    state.selectedFiles = new Set(all ? (state.estimate?.files || []).map(({ id }) => id) : []);
    renderFiles();
    updateSummary();
  }

  function chooseProjects(all) {
    state.selectedProjects = new Set(all ? (state.estimate?.projects || []).map(({ id }) => id) : []);
    for (const item of state.refs.lightList.querySelectorAll('input[data-project-id]')) {
      item.checked = state.selectedProjects.has(item.dataset.projectId);
    }
    updateSummary();
  }

  function visibleLightProjects() {
    const query = state.refs.lightSearch.value.trim().toLocaleLowerCase('zh-CN');
    return (state.estimate?.projects || []).filter((project) =>
      (project.name || '').toLocaleLowerCase('zh-CN').includes(query)
    );
  }

  function renderLightProjects() {
    const { lightList } = state.refs;
    clear(lightList);
    const projects = visibleLightProjects();
    for (const project of projects) {
      const item = checkbox(project.name, state.selectedProjects.has(project.id), (checked) => {
        checked ? state.selectedProjects.add(project.id) : state.selectedProjects.delete(project.id);
        updateSummary();
      }, `${tokenCount(project.total)} Token · ${num(project.modelCount)} 个模型 · ${num(project.sessions)} 个会话 · ${dateRange(project)} · 约 ${bytes(project.bytes)}`);
      item.querySelector('input').dataset.projectId = project.id;
      lightList.append(item);
    }
    if (!projects.length) {
      const message = state.estimate?.projects?.length ? '未找到匹配的项目。' : '暂无可用的项目用量。';
      lightList.append(node('p', message, 'backup-empty'));
    }
    updateSummary();
  }

  function checkbox(label, checked, onChange, detail) {
    const wrap = node('label', undefined, 'backup-choice');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = checked;
    input.addEventListener('change', () => onChange(input.checked));
    const copy = node('span');
    copy.append(node('strong', label));
    if (detail) copy.append(node('small', detail));
    wrap.append(input, copy);
    return wrap;
  }
  function renderSources() {
    clear(state.refs.sourceList);
    for (const source of state.estimate.sources || []) {
      const available = source.available !== false;
      const detail = `${sourceSessions(source)} 个候选会话 · 源数据 ${bytes(sourceBytes(source))}${source.note ? ` · ${source.note}` : ''}`;
      const item = checkbox(
        source.name || source.id,
        state.selectedSources.has(source.id),
        (checked) => {
          checked ? state.selectedSources.add(source.id) : state.selectedSources.delete(source.id);
          updateSummary();
        },
        detail
      );
      item.classList.toggle('is-unavailable', !available);
      item.querySelector('input').disabled = !available;
      state.refs.sourceList.append(item);
    }
  }
  function categoryName(id) {
    const category = (state.estimate.categories || []).find(item => item.id === id);
    return category?.name || id || '其他';
  }
  function filteredFiles() {
    const project = state.refs.projectFilter.value;
    const category = state.refs.categoryFilter.value;
    return (state.estimate.files || []).filter(file => (
      (!project || (file.project || '未归类') === project) &&
      (!category || (file.category || '其他') === category)
    ));
  }
  function renderFiles() {
    clear(state.refs.fileList);
    const filtered = filteredFiles();
    const allSelected = filtered.length > 0 && filtered.every(file => state.selectedFiles.has(file.id));
    state.refs.bulk.textContent = allSelected ? '取消当前筛选' : '选择当前筛选';
    state.refs.bulk.disabled = !filtered.length;
    if (!filtered.length) {
      state.refs.fileList.append(node('p', '没有符合条件的可选文件。', 'backup-empty'));
      return;
    }
    const groups = new Map();
    for (const file of filtered) {
      const key = `${file.category || '其他'}\u0000${file.project || '未归类'}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(file);
    }
    for (const [key, list] of groups) {
      const [category, projectName] = key.split('\u0000');
      const group = node('div', undefined, 'backup-file-group');
      group.append(node('h4', `${categoryName(category)} · ${projectName}`));
      for (const file of list) {
        const item = checkbox(
          file.name || file.relativePath || file.id,
          state.selectedFiles.has(file.id),
          (checked) => {
            checked ? state.selectedFiles.add(file.id) : state.selectedFiles.delete(file.id);
            updateSummary();
          },
          `${file.relativePath || ''}${file.relativePath ? ' · ' : ''}${bytes(file.size)}`
        );
        group.append(item);
      }
      state.refs.fileList.append(group);
    }
  }
  function projects() {
    const prior = state.refs.projectFilter.value;
    clear(state.refs.projectFilter);
    state.refs.projectFilter.append(new Option('全部项目', ''));
    const names = [...new Set((state.estimate.files || []).map((f) => f.project || '未归类'))].sort(
      (a, b) => a.localeCompare(b, 'zh-CN')
    );
    for (const name of names) state.refs.projectFilter.append(new Option(name, name));
    state.refs.projectFilter.value = names.includes(prior) ? prior : '';
    const priorCategory = state.refs.categoryFilter.value;
    clear(state.refs.categoryFilter);
    state.refs.categoryFilter.append(new Option('全部类别', ''));
    const categoryIds = [...new Set((state.estimate.files || []).map(file => file.category || '其他'))];
    for (const id of categoryIds) state.refs.categoryFilter.append(new Option(categoryName(id), id));
    state.refs.categoryFilter.value = categoryIds.includes(priorCategory) ? priorCategory : '';
  }
  function updateSummary() {
    const refs = state.refs;
    const light = state.mode === 'light';
    const selected = light ? state.selectedProjects.size : state.selectedSources.size + state.selectedFiles.size;
    const busy = state.submitting || Boolean(state.jobId);
    refs.start.disabled = !state.estimate || !selected || busy || state.importing || state.choosingDestination;
    refs.importButton.disabled = busy || state.importing;
    refs.chooseLocation.disabled = busy || state.choosingDestination;
    refs.defaultLocation.hidden = !state.destination;
    refs.defaultLocation.disabled = refs.chooseLocation.disabled;
    const d = state.destination ?? state.estimate?.destination ?? {};
    const freeBytes = d.freeBytes == null ? null : num(d.freeBytes);
    refs.destination.textContent = (d.label || '本项目“备份”文件夹')
      + (freeBytes === null ? '' : ` · 可用空间 ${bytes(freeBytes)}`);
    if (!light) {
      const totalFiles = state.estimate?.files?.length || 0;
      refs.fullAll.disabled = !totalFiles || state.selectedFiles.size === totalFiles;
      refs.fullNone.disabled = !totalFiles || state.selectedFiles.size === 0;
    }
    if (light) {
      const projects = state.estimate?.projects || [];
      refs.lightAll.disabled = projects.length === 0 || selected === projects.length;
      refs.lightNone.disabled = selected === 0 || !state.estimate;
      refs.lightSearch.disabled = projects.length === 0;
      refs.lightCount.textContent = state.estimate
        ? `显示 ${visibleLightProjects().length} / ${projects.length} 个项目 · 已选 ${selected} 个`
        : '';
    }
    if (!state.estimate) return;
    if (light) {
      const chosen = (state.estimate.projects || []).filter(({ id }) => state.selectedProjects.has(id));
      const total = chosen.reduce((sum, project) => sum + num(project.total), 0);
      const size = chosen.reduce((sum, project) => sum + num(project.bytes), 0);
      const coverage = { from: null, to: null };
      for (const { from, to } of chosen) {
        if (from && (!coverage.from || from < coverage.from)) coverage.from = from;
        if (to && (!coverage.to || to > coverage.to)) coverage.to = to;
      }
      refs.summaryStrong.textContent = `已选 ${chosen.length} 个项目 · ${tokenCount(total)} Token`;
      refs.summaryNote.textContent = chosen.length
        ? `汇总数据约 ${bytes(size)}（打包前）· ${dateRange(coverage)}`
        : '勾选项目即可查看数据范围和大小。';
      return;
    }
    const filesInScope = filteredFiles();
    if (state.refs.bulk) {
      state.refs.bulk.textContent = filesInScope.length && filesInScope.every(file => state.selectedFiles.has(file.id))
        ? '取消当前筛选'
        : '选择当前筛选';
    }
    const sources = (state.estimate.sources || []).filter((s) => state.selectedSources.has(s.id));
    const files = (state.estimate.files || []).filter((f) => state.selectedFiles.has(f.id));
    const selectedSourceBytes = sources.reduce((sum, s) => sum + sourceBytes(s), 0);
    const availableBytes = (state.estimate.sources || [])
      .filter((s) => s.available !== false)
      .reduce((sum, s) => sum + sourceBytes(s), 0);
    const fileBytes = files.reduce((sum, f) => sum + num(f.size), 0);
    const fraction = availableBytes ? selectedSourceBytes / availableBytes : 0;
    const estimate = state.estimate.estimate || {};
    const samples = sources.map(source => source.sampleEstimate).filter(sample => (
      sample && Number.isFinite(Number(sample.minBytes)) && Number.isFinite(Number(sample.maxBytes))
    ));
    const sampled = sources.length > 0 && samples.length === sources.length;
    const min = (sampled ? samples.reduce((sum, sample) => sum + num(sample.minBytes), 0) : num(estimate.minBytes ?? estimate.packageMinBytes) * fraction) + fileBytes;
    const max = (sampled ? samples.reduce((sum, sample) => sum + num(sample.maxBytes), 0) : num(estimate.maxBytes ?? estimate.packageMaxBytes) * fraction) + fileBytes;
    const candidates = sources.reduce((sum, s) => sum + sourceSessions(s), 0);
    state.refs.summaryStrong.textContent = `已选 ${sources.length} 个来源、${candidates} 个候选会话、${files.length} 个附件`;
    const spaceWarning =
      freeBytes === null
        ? '可用空间暂时未知，开始前请确认磁盘空间。'
        : max > freeBytes
          ? '预计归档可能超过当前可用空间，请清理空间或缩小选择。'
          : '';
    state.refs.summaryNote.textContent = `候选源数据体积 ${bytes(selectedSourceBytes)}${fileBytes ? `，附件 ${bytes(fileBytes)}` : ''}；归档预计 ${bytes(min)} – ${bytes(max)}${sampled ? '（按渠道抽样测得）' : '（按当前扫描比例推算）'}。实际大小会受压缩与文件变化影响。${spaceWarning ? ` 注意：${spaceWarning}` : ''}`;
  }
  async function loadRecent() {
    const request = ++state.recentRequest;
    const query = state.destination?.id ? `?destinationId=${encodeURIComponent(state.destination.id)}` : '';
    try {
      const data = await api(`/api/backup/list${query}`);
      if (request !== state.recentRequest) return;
      clear(state.refs.recentList);
      const backups = Array.isArray(data.backups) ? data.backups : [];
      if (!backups.length) {
        state.refs.recentList.append(node('p', '还没有创建备份。', 'backup-empty'));
        return;
      }
      for (const backup of backups) {
        const row = node('div', undefined, 'backup-recent-row');
        const copy = node('div');
        copy.append(
          node('strong', backup.name),
          node('small', [modeName(backup.mode), backup.encrypted === false ? '无密码' : '有密码', bytes(backup.bytes), backup.location, backup.createdAt].filter(Boolean).join(' · '))
        );
        const actions = node('div', undefined, 'backup-recent-actions');
        const view = node('button', '查看', 'button button--small');
        view.type = 'button';
        view.addEventListener('click', () => viewBackup(backup, view));
        const download = node('a', '下载备份包', 'button button--small');
        const downloadQuery = new URLSearchParams({ name: backup.name });
        if (backup.destinationId) downloadQuery.set('destinationId', backup.destinationId);
        download.href = `/api/backup/download?${downloadQuery}`;
        download.setAttribute('download', '');
        actions.append(view, download);
        row.append(copy, actions);
        state.refs.recentList.append(row);
      }
    } catch (error) {
      if (request !== state.recentRequest) return;
      clear(state.refs.recentList);
      state.refs.recentList.append(node('p', error.message, 'backup-error'));
    }
  }
  function viewBackup(backup, trigger) {
    const { name, mode, destinationId } = backup;
    const encrypted = backup.encrypted !== false;
    if (trigger) trigger.disabled = true;
    const viewer = document.createElement('dialog');
    viewer.className = 'backup-viewer';
    viewer.setAttribute('aria-label', `查看备份 ${name}`);
    const box = node('div', undefined, 'backup-viewer-box');
    const top = node('header', undefined, 'backup-head');
    top.append(node('h2', `备份内容 · ${name}`));
    const close = node('button', '关闭', 'backup-close');
    close.type = 'button';
    close.addEventListener('click', () => viewer.close());
    top.append(close);
    const form = document.createElement('form');
    form.className = 'backup-view-auth';
    const password = document.createElement('input');
    password.type = 'password';
    password.required = encrypted;
    password.minLength = 10;
    password.autocomplete = 'current-password';
    password.placeholder = '输入此备份的加密密码';
    const query = document.createElement('input');
    query.type = 'search';
    query.placeholder = '可选：关键词筛选会话';
    const submit = node('button', encrypted ? '解密并查看' : '查询', 'button button--small');
    submit.type = 'submit';
    const authStatus = node('p', encrypted ? '密码只在此窗口中临时使用，关闭后立即清除。' : '', 'backup-help');
    authStatus.setAttribute('role', 'status');
    const passwordLabel = node('label', '加密密码');
    passwordLabel.append(password);
    passwordLabel.hidden = !encrypted;
    password.disabled = !encrypted;
    form.classList.toggle('backup-view-auth-plain', !encrypted);
    const queryLabel = node('label', '关键词');
    queryLabel.append(query);
    queryLabel.hidden = mode === 'light';
    form.append(passwordLabel, queryLabel, submit);
    form.hidden = !encrypted && mode === 'light';
    const content = node('div', undefined, 'backup-authenticated');
    const requestView = async () => {
      submit.disabled = true;
      authStatus.textContent = '正在读取本机备份…';
      try {
        const data = await api('/api/backup/view', {
          method: 'POST',
          body: JSON.stringify({
            name,
            destinationId,
            ...(encrypted ? { passphrase: password.value } : {}),
            query: query.value.trim() || undefined,
          }),
        });
        const light = data.manifest?.mode === 'light';
        queryLabel.hidden = light;
        form.hidden = !encrypted && light;
        authStatus.textContent = encrypted ? '已验证密码。' : '已读取备份。';
        renderArchive(backup, data, password, content);
      } catch (error) {
        authStatus.textContent = error.message;
      } finally {
        submit.disabled = false;
      }
    };
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      requestView();
    });
    box.append(top, form, authStatus, content);
    viewer.append(box);
    document.body.append(viewer);
    viewer.addEventListener('close', () => {
      password.value = '';
      query.value = '';
      if (trigger) trigger.disabled = false;
      viewer.remove();
    });
    viewer.showModal();
    if (encrypted) password.focus();
    else requestView();
  }
  function renderLightArchive(usage, content) {
    const projects = Array.isArray(usage?.projects) ? usage.projects : [];
    content.append(node('p', `轻量备份 · ${projects.length} 个项目 · ${dateRange(usage || {})}`, 'backup-view-counts'));
    if (!projects.length) {
      content.append(node('p', '此备份中没有项目用量。', 'backup-empty'));
      return;
    }
    const overview = node('section', undefined, 'backup-section');
    const label = node('label', '项目');
    const select = node('select', undefined, 'backup-view-filter');
    for (const [index, project] of projects.entries()) select.add(new Option(project.name, String(index)));
    label.append(select);
    const detail = node('div');
    overview.append(label, detail);
    content.append(overview);
    const sourceNames = { codex: 'Codex', claude: 'Claude Code', workbuddy: 'Workbuddy' };
    function showProject() {
      const project = projects[Number(select.value)];
      if (!project) return;
      clear(detail);
      detail.append(
        node('h3', project.name),
        node('p', `${tokenCount(project.total)} Token · ${num(project.sessions)} 个会话 · ${dateRange(project)}`, 'backup-help')
      );
      const groups = node('dl', undefined, 'backup-light-models');
      for (const model of project.models || []) {
        const row = node('div', undefined, 'backup-light-model');
        row.append(node('dt', `${sourceNames[model.source] || model.source} · ${model.name}`));
        const copy = node('dd', `${tokenCount(model.total)} Token`);
        const effort = model.reasoningEfforts || [];
        const unrecorded = Math.max(0, num(model.total) - effort.reduce((sum, item) => sum + num(item.total), 0));
        const amounts = effort.map(item => `${item.effort} ${tokenCount(item.total)}`);
        if (unrecorded > 0) amounts.push(`未记录 ${tokenCount(unrecorded)}`);
        if (amounts.length) copy.append(node('small', `推理强度与 Token · ${amounts.join(' · ')}`));
        const settings = model.reasoningSettings || [];
        if (settings.length || model.reasoningSettingsSupported) {
          const labels = { enabled: '已开启', disabled: '已关闭' };
          const summaries = settings.map(item => `${labels[item.setting] || item.setting} ${num(item.sessions)} 个会话`);
          const missing = Math.max(0, num(model.sessions) - settings.reduce((sum, item) => sum + num(item.sessions), 0));
          if (missing > 0) summaries.push(`未记录 ${missing} 个会话`);
          if (summaries.length) copy.append(node('small', `保存的会话设置 · ${summaries.join(' · ')}`));
        }
        row.append(copy);
        groups.append(row);
      }
      detail.append(groups);
    }
    select.addEventListener('change', showProject);
    showProject();
  }
  function renderArchive({ name, destinationId, encrypted }, data, password, content) {
    clear(content);
    if (data.manifest?.mode === 'light') {
      renderLightArchive(data.manifest.usage, content);
      return;
    }
    const counts = data.counts || {};
    const conversations = Array.isArray(data.conversations) ? data.conversations.slice(0, 50) : [];
    const manifestFiles = Array.isArray(data.manifest && data.manifest.files)
      ? data.manifest.files
      : [];
    const conversationCount = counts.conversations ?? counts.sessions ?? conversations.length;
    const fileCount = counts.files ?? manifestFiles.length;
    const status = data.status ?? (data.manifest && data.manifest.status) ?? '已验证';
    const facts = [`会话 ${conversationCount}`, `文件 ${fileCount}`];
    if (counts.messages !== undefined) facts.splice(1, 0, `消息 ${counts.messages}`);
    content.append(node('p', `备份状态：${status} · ${facts.join(' · ')}`, 'backup-view-counts'));
    if (conversations.length) {
      const list = node('div', undefined, 'backup-view-list');
      for (const c of conversations) {
        const details = document.createElement('details');
        details.className = 'backup-conversation';
        details.append(
          node(
            'summary',
            `${c.project || '未归类'} · ${c.source || '本地来源'} · ${c.title || '未命名会话'}`
          )
        );
        const messages = Array.isArray(c.messages) ? c.messages.slice(0, 12) : [];
        for (const m of messages) {
          const msg = node('article', undefined, 'backup-message');
          msg.append(
            node('small', `${m.role || 'message'}${m.at ? ` · ${m.at}` : ''}`),
            node('p', m.text || '')
          );
          details.append(msg);
        }
        if ((c.messages || []).length > messages.length)
          details.append(node('p', '为保护性能，此处仅展示前 12 条消息。', 'backup-help'));
        list.append(details);
      }
      content.append(list);
    } else {
      content.append(
        node(
          'p',
          fileCount
            ? '此备份没有可读取会话，但包含可恢复的附件或项目文件。'
            : '此备份中没有可读取会话或文件。',
          'backup-empty'
        )
      );
    }
    if (data.truncated)
      content.append(
        node('p', '本次查看结果已限量展示；可使用上方关键词重新查询。', 'backup-help')
      );
    if (manifestFiles.length) {
      const restore = node('section', undefined, 'backup-restore');
      restore.append(node('h3', '恢复文件到本机'));
      const select = document.createElement('select');
      select.setAttribute('aria-label', '选择要恢复的文件');
      for (const file of manifestFiles)
        select.append(
          new Option(
            `${file.project || '未归类'} · ${file.name || file.relativePath || file.id} · ${bytes(file.size)}`,
            file.id
          )
        );
      const restoreButton = node('button', '恢复到本机', 'button button--small');
      restoreButton.type = 'button';
      const restoreStatus = node(
        'p',
        '会将选中的附件恢复到本机的恢复文件夹。',
        'backup-help'
      );
      restoreButton.addEventListener('click', async () => {
        restoreButton.disabled = true;
        restoreStatus.textContent = '正在恢复到本机…';
        try {
          const result = await api('/api/backup/restorefile', {
            method: 'POST',
            body: JSON.stringify({
              name, destinationId, fileId: select.value,
              ...(encrypted === false ? {} : { passphrase: password.value }),
            }),
          });
          restoreStatus.textContent = result.location
            ? `已恢复到：${result.location}`
            : result.message || '文件已恢复到本机。';
        } catch (error) {
          restoreStatus.textContent = error.message;
        } finally {
          restoreButton.disabled = false;
        }
      });
      restore.append(select, restoreButton, restoreStatus);
      content.append(restore);
    }
  }
  async function startBackup() {
    if (!state.estimate || state.submitting || state.jobId || state.importing || state.choosingDestination) return;
    const encrypted = state.refs.protection.value !== 'plain';
    const password = state.refs.password.value;
    const confirmPassword = state.refs.confirmPassword.value;
    if (encrypted && password.length < 10) {
      state.refs.password.focus();
      window.alert('加密密码至少需要 10 个字符。');
      return;
    }
    if (encrypted && password !== confirmPassword) {
      state.refs.confirmPassword.focus();
      window.alert('两次输入的密码不一致。');
      return;
    }
    const light = state.mode === 'light';
    if (light ? !state.selectedProjects.size : !state.selectedSources.size && !state.selectedFiles.size) {
      window.alert(light ? '请至少选择一个项目。' : '请至少选择一个会话来源或附件。');
      return;
    }
    if (
      !window.confirm(
        encrypted
          ? '将创建加密备份。请妥善保管密码。是否开始？'
          : '将创建无密码备份，能访问该文件的人可以读取内容。是否开始？'
      )
    )
      return;
    state.submitting = true;
    updateSummary();
    state.refs.progress.hidden = false;
    state.refs.progressText.textContent = '正在创建本机备份…';
    try {
      const data = await api('/api/backup/start', {
        method: 'POST',
        body: JSON.stringify({
          mode: state.mode,
          scanId: state.estimate.scanId,
          ...(light
            ? { projects: [...state.selectedProjects] }
            : { sources: [...state.selectedSources], files: [...state.selectedFiles] }),
          destinationId: state.destination?.id,
          encrypted,
          ...(encrypted ? { passphrase: password } : {}),
        }),
      });
      state.refs.password.value = '';
      state.refs.confirmPassword.value = '';
      state.jobId = data.jobId;
      poll();
    } catch (error) {
      state.refs.progressText.textContent = error.message;
    } finally {
      state.submitting = false;
      updateSummary();
    }
  }
  async function poll() {
    if (!state.jobId || state.polling) return;
    state.polling = true;
    state.timer = 0;
    try {
      const job = await api(`/api/backup/status?jobId=${encodeURIComponent(state.jobId)}`);
      const total = Math.max(1, num(job.total));
      state.refs.meter.max = total;
      state.refs.meter.value = Math.min(total, num(job.processed));
      state.refs.progressText.textContent = `${job.phase || '正在备份'} · ${num(job.processed)}/${num(job.total)}${job.fileName ? ` · ${job.fileName}` : ''}`;
      if (job.state === 'complete') {
        const counts = job.counts || {};
        const facts = [];
        if (job.bytes !== undefined) facts.push(`归档 ${bytes(job.bytes)}`);
        if (counts.projects !== undefined) facts.push(`项目 ${counts.projects}`);
        if (counts.conversations !== undefined) facts.push(`会话 ${counts.conversations}`);
        if (counts.messages !== undefined) facts.push(`消息 ${counts.messages}`);
        if (counts.files !== undefined) facts.push(`文件 ${counts.files}`);
        state.refs.progressText.textContent = `${job.message || '备份已完成'}${facts.length ? ` · ${facts.join(' · ')}` : ''}。换机时可在新电脑选择「导入备份」。`;
        state.jobId = '';
        updateSummary();
        loadRecent();
        return;
      }
      if (job.state === 'error') {
        state.refs.progressText.textContent = job.message || '备份未完成。';
        state.jobId = '';
        updateSummary();
        return;
      }
      if (state.dialog.open) state.timer = window.setTimeout(poll, 900);
    } catch (error) {
      state.refs.progressText.textContent = error.message;
      state.jobId = '';
      updateSummary();
    } finally {
      state.polling = false;
    }
  }
  async function loadEstimate(mode) {
    state.mode = mode;
    state.estimate = null;
    const request = ++state.estimateRequest;
    state.loadingEstimate = true;
    const light = mode === 'light';
    const refs = state.refs;
    for (const [kind, button] of Object.entries(refs.modeButtons)) {
      button.setAttribute('aria-pressed', String(kind === mode));
    }
    refs.intro.textContent = light
      ? '只保存项目用量汇总。换电脑后可以导入备份查看。'
      : '完整备份保存所选渠道的会话正文，并可加入项目文件。';
    refs.light.hidden = !light;
    refs.sources.hidden = refs.files.hidden = light;
    refs.status.textContent = light ? '正在整理项目用量…' : '正在盘点本机可备份内容…';
    refs.summaryStrong.textContent = '等待盘点';
    refs.summaryNote.textContent = '';
    for (const list of [refs.lightList, refs.sourceList, refs.fileList]) clear(list);
    refs.bulk.disabled = refs.categoryFilter.disabled = refs.projectFilter.disabled = true;
    updateSummary();
    try {
      const data = await api(`/api/backup/${light ? 'lightestimate' : 'estimate'}`, {
        method: 'POST',
        body: '{}',
      });
      if (request !== state.estimateRequest) return;
      state.estimate = data;
      const first = !state.initializedModes.has(mode);
      state.initializedModes.add(mode);
      if (light) {
        state.selectedProjects = new Set((data.projects || [])
          .filter(project => first || state.selectedProjects.has(project.id)).map(project => project.id));
        renderLightProjects();
      } else {
        state.selectedSources = new Set((data.sources || [])
          .filter(source => source.available !== false && (first || state.selectedSources.has(source.id)))
          .map(source => source.id));
        state.selectedFiles = new Set((data.files || [])
          .filter(file => state.selectedFiles.has(file.id)).map(file => file.id));
        refs.categoryFilter.disabled = refs.projectFilter.disabled = false;
        renderSources();
        projects();
        renderFiles();
      }
      updateSummary();
      refs.status.textContent = data.omitted
        ? `盘点完成 · ${data.omitted}`
        : `盘点完成 · ${data.generatedAt || '刚刚更新'}`;
    } catch (error) {
      if (request === state.estimateRequest) refs.status.textContent = error.message;
    } finally {
      if (request === state.estimateRequest) state.loadingEstimate = false;
    }
  }
  function open() {
    if (!ensure()) return;
    state.dialog.showModal();
    state.dialog.querySelector('.backup-close')?.focus();
    state.initializedModes.clear();
    state.selectedFiles.clear();
    state.refs.lightSearch.value = '';
    loadEstimate('light');
    if (state.jobId) {
      state.refs.progress.hidden = false;
      state.refs.progressText.textContent = '正在恢复本机备份进度…';
      if (!state.timer) poll();
    }
    loadRecent();
  }
  function init() {
    const button = $('backup-open');
    if (button && !button.dataset.backupBound) {
      button.dataset.backupBound = 'true';
      button.addEventListener('click', open);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
