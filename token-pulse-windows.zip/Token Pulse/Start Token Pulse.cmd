@echo off
setlocal
pushd "%~dp0" || exit /b 1
where.exe node >nul 2>nul
if errorlevel 1 (
  echo Token Pulse requires Node.js 22.15 or later.
  echo Download Node.js from https://nodejs.org/en/download
  pause
  exit /b 1
)
node app\server.mjs --open
set "token_pulse_exit=%errorlevel%"
popd
if not "%token_pulse_exit%"=="0" pause
exit /b %token_pulse_exit%
