import { createHash } from 'node:crypto';
import { createReadStream, existsSync } from 'node:fs';
import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { createInterface } from 'node:readline';
import { DatabaseSync } from 'node:sqlite';
import { normalizeReasoningEffort, normalizeReasoningSetting } from '../metrics.mjs';
import { claudeProjects, recordedPathLabel, workbuddyDirectory } from '../source-paths.mjs';

const dayFormatter = new Intl.DateTimeFormat('sv-SE', {
  timeZone: 'Asia/Singapore',
  dateStyle: 'short',
});
const hourFormatter = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Singapore',
  hour: 'numeric',
  hourCycle: 'h23',
});

function pseudonym(value) {
  return createHash('sha256').update(String(value)).digest('hex').slice(0, 18);
}

function dateFor(value) {
  const time = typeof value === 'number' ? value : Date.parse(value);
  return Number.isFinite(time) ? dayFormatter.format(time) : null;
}

function wholeNumber(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

function projectFromDirectory(value) {
  return recordedPathLabel(value, { excludeHome: true });
}

async function findJsonl(directory) {
  const files = [];
  let entries;
  try {
    entries = await readdir(directory, { withFileTypes: true });
  } catch {
    return files;
  }
  for (const entry of entries) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await findJsonl(file));
    if (entry.isFile() && entry.name.endsWith('.jsonl')) files.push(file);
  }
  return files;
}

function unavailable(id, name, note) {
  return {
    rows: [],
    status: { id, name, quality: 'unavailable', note, files: 0, parsed: 0, skipped: 0 },
  };
}

export async function collectClaude() {
  const root = claudeProjects();
  if (!existsSync(root)) return unavailable('claude', 'Claude Code', '未找到本机 Claude Code 会话目录');

  const files = await findJsonl(root);
  const records = new Map();
  let parsed = 0;
  let skipped = 0;

  for (const file of files) {
    try {
      const input = createReadStream(file, { encoding: 'utf8' });
      const lines = createInterface({ input, crlfDelay: Infinity });
      for await (const line of lines) {
        if (!line.includes('"assistant"') || !line.includes('"usage"')) continue;
        let event;
        try {
          event = JSON.parse(line);
        } catch {
          skipped++;
          continue;
        }
        const usage = event.type === 'assistant' ? event.message?.usage : null;
        if (!usage || event.message?.role !== 'assistant') continue;

        const inputTokens = wholeNumber(usage.input_tokens);
        const cacheRead = wholeNumber(usage.cache_read_input_tokens) ?? 0;
        const cacheWrite = wholeNumber(usage.cache_creation_input_tokens) ?? 0;
        const outputTokens = wholeNumber(usage.output_tokens);
        const date = dateFor(event.timestamp);
        if (inputTokens === null || outputTokens === null || !date) {
          skipped++;
          continue;
        }
        const requestIdentity = event.message?.id || event.requestId || event.uuid;
        if (!requestIdentity) {
          skipped++;
          continue;
        }
        const reasoningEffort = normalizeReasoningEffort(event.perTurnEffort);
        const row = {
          date,
          hour: Number(hourFormatter.format(new Date(event.timestamp))),
          sessionKey: pseudonym(event.sessionId || file),
          project: projectFromDirectory(event.cwd),
          model: typeof event.message?.model === 'string' ? event.message.model : 'Claude',
          input: inputTokens + cacheRead + cacheWrite,
          cached: cacheRead,
          output: outputTokens,
          total: inputTokens + cacheRead + cacheWrite + outputTokens,
          estimated: false,
          ...(reasoningEffort ? { reasoningEffort } : {}),
        };
        const key = pseudonym(requestIdentity);
        if (!records.has(key) || records.get(key).total <= row.total) records.set(key, row);
      }
    } catch {
      skipped++;
    }
  }
  const rows = [...records.values()];
  parsed = rows.length;
  return {
    rows,
    status: {
      id: 'claude',
      name: 'Claude Code',
      quality: parsed ? 'measured' : 'unavailable',
      note: parsed ? '来自本机 Claude Code 会话用量记录' : '未发现可统计的 Claude Code 用量记录',
      files: files.length,
      parsed,
      skipped,
    },
  };
}

export async function collectWorkbuddy() {
  const dbPath = path.join(workbuddyDirectory(), 'workbuddy.db');
  if (!existsSync(dbPath)) return unavailable('workbuddy', 'Workbuddy', '未找到本机 Workbuddy 数据库');

  let database;
  try {
    database = new DatabaseSync(dbPath, { readOnly: true });
    const hasThoughtLevel = database.prepare(
      "SELECT name FROM pragma_table_info('sessions') WHERE name = 'thought_level'",
    ).get();
    const rows = database.prepare(`
      SELECT u.session_id, u.used, u.updated_at, s.created_at, s.model, s.cwd,
        ${hasThoughtLevel ? 's.thought_level' : 'NULL'} AS thought_level
      FROM session_usage u
      LEFT JOIN sessions s ON s.id = u.session_id
      WHERE u.used > 0
    `).all();
    const normalized = [];
    let skipped = 0;
    for (const row of rows) {
      const total = wholeNumber(row.used);
      const date = dateFor(row.updated_at || row.created_at);
      if (total === null || !date) {
        skipped++;
        continue;
      }
      const reasoningSetting = normalizeReasoningSetting(row.thought_level);
      normalized.push({
        date,
        sessionKey: pseudonym(row.session_id),
        project: projectFromDirectory(row.cwd),
        model: typeof row.model === 'string' && row.model ? row.model : 'Workbuddy',
        input: null,
        cached: null,
        output: null,
        total,
        estimated: false,
        ...(reasoningSetting ? { reasoningSetting } : {}),
      });
    }
    return {
      rows: normalized,
      status: {
        id: 'workbuddy',
        name: 'Workbuddy',
        quality: normalized.length ? 'measured' : 'unavailable',
        note: normalized.length
          ? '来自 Workbuddy 会话累计 token，输入和输出未单独记录'
          : '未发现可统计的 Workbuddy 会话用量',
        files: 1,
        parsed: normalized.length,
        skipped,
        reasoningSettingsSupported: Boolean(hasThoughtLevel),
      },
    };
  } catch {
    return unavailable('workbuddy', 'Workbuddy', 'Workbuddy 数据库暂时不可读取');
  } finally {
    database?.close();
  }
}
