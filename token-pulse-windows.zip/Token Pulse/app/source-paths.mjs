import { homedir } from 'node:os';
import path from 'node:path';

export function codexHomes(configured = process.env.CODEX_HOME || path.join(homedir(), '.codex')) {
  return [...new Set(configured.split(',').map(value => value.trim()).filter(Boolean))];
}

export function claudeProjects() {
  return path.join(process.env.CLAUDE_CONFIG_DIR?.trim() || path.join(homedir(), '.claude'), 'projects');
}

export function workbuddyDirectory() {
  return process.env.TOKEN_PULSE_WORKBUDDY_DIR?.trim() || path.join(homedir(), '.workbuddy');
}

export function workbuddyTranscriptDirectories(root = workbuddyDirectory()) {
  if (process.platform !== 'darwin' || process.env.TOKEN_PULSE_WORKBUDDY_DIR?.trim()) return [root];
  return [root, path.join(homedir(), 'Library', 'Application Support', 'Workbuddy')];
}

export function recordedPathLabel(value, { excludeHome = false } = {}) {
  if (typeof value !== 'string' || !value.trim()) return null;
  const text = value.trim();
  const windows = !text.startsWith('/') && (text.includes('\\') || /^[a-z]:/i.test(text));
  const flavor = windows ? path.win32 : path.posix;
  const normalized = flavor.normalize(text);
  const withoutTrailingSlashes = item => item.replace(/[\\/]+$/, '');
  const comparable = item => {
    const canonical = withoutTrailingSlashes(flavor.normalize(item));
    return windows ? canonical.toLowerCase() : canonical;
  };
  if (excludeHome && comparable(normalized) === comparable(homedir())) return null;
  const label = flavor.basename(normalized);
  return label && !['.', '..', '~'].includes(label) ? label : null;
}
