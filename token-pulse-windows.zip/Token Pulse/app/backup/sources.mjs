import { createHash } from 'node:crypto';
import { createReadStream, existsSync } from 'node:fs';
import { open, readdir, realpath, stat } from 'node:fs/promises';
import path from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { DatabaseSync } from 'node:sqlite';
import { createZstdDecompress } from 'node:zlib';
import { claudeProjects, codexHomes, recordedPathLabel, workbuddyDirectory, workbuddyTranscriptDirectories } from '../source-paths.mjs';

const MAX_LINE_LENGTH = 8 * 1024 * 1024;
const MAX_TEXT_LENGTH = 4 * 1024 * 1024;

function digest(value) {
  return createHash('sha256').update(String(value)).digest('hex').slice(0, 24);
}

function labelFromPath(value) {
  return recordedPathLabel(value)?.slice(0, 160) ?? null;
}

function validText(value) {
  if (typeof value !== 'string' || !value) return null;
  // Inline images/binary payloads are not portable transcripts and can make a backup enormous.
  if (/^data:[^,]+;base64,/i.test(value)) return null;
  return value.slice(0, MAX_TEXT_LENGTH);
}

function textFromContent(content) {
  if (typeof content === 'string') return validText(content);
  if (!Array.isArray(content)) return null;
  const text = content.flatMap(item => {
    if (typeof item === 'string') return [item];
    if (!item || typeof item !== 'object') return [];
    if (['text', 'input_text', 'output_text'].includes(item.type)) return [item.text];
    if (/^(?:(?:input|output)_)?(?:image|image_url|file|attachment|document|video|audio)$/i.test(item.type || '')) {
      const filename = labelFromPath(item.filename || item.file_name);
      const kind = /image/i.test(item.type) ? '图片' : '附件';
      return [filename ? `[${kind}：${filename}]` : `[${kind}]`];
    }
    return [];
  }).map(validText).filter(Boolean).join('\n');
  return text || null;
}

async function* linesFromFile(file, isZstd = false, byteLimit = Infinity) {
  const input = createReadStream(file, { highWaterMark: 1024 * 1024 });
  const stream = isZstd ? input.pipe(createZstdDecompress()) : input;
  if (stream !== input) input.on('error', error => stream.destroy(error));
  const decoder = new StringDecoder('utf8');
  let pending = '';
  let discarding = false;
  let bytes = 0;
  try {
    for await (const chunk of stream) {
      bytes += chunk.length;
      if (bytes > byteLimit) return;
      pending += decoder.write(chunk);
      let newline;
      while ((newline = pending.indexOf('\n')) !== -1) {
        const line = pending.slice(0, newline);
        pending = pending.slice(newline + 1);
        if (discarding) { discarding = false; continue; }
        yield line;
      }
      if (pending.length > MAX_LINE_LENGTH) { pending = ''; discarding = true; }
    }
    pending += decoder.end();
    if (!discarding && pending) yield pending;
  } finally {
    input.destroy();
  }
}

async function walkJsonl(directory, files, { compressed = false } = {}) {
  let children;
  try { children = await readdir(directory, { withFileTypes: true }); } catch { return; }
  for (const child of children) {
    const file = path.join(directory, child.name);
    if (child.isDirectory()) {
      await walkJsonl(file, files, { compressed });
    } else if (child.isFile() && (compressed ? child.name.endsWith('.jsonl.zst') : child.name.endsWith('.jsonl'))) {
      try { files.push({ file, size: (await stat(file)).size }); } catch {}
    }
  }
}

async function discoverCodex(home) {
  const candidates = [];
  await walkJsonl(path.join(home, 'sessions'), candidates);
  await walkJsonl(path.join(home, 'sessions'), candidates, { compressed: true });
  await walkJsonl(path.join(home, 'archived_sessions'), candidates);
  await walkJsonl(path.join(home, 'archived_sessions'), candidates, { compressed: true });
  const selected = new Map();
  for (const candidate of candidates) {
    // A session log has a UUID filename. Using it as the key also eliminates copies
    // left behind when a session moves between active and archived locations.
    const base = path.basename(candidate.file).replace(/\.zst$/, '');
    const active = candidate.file.includes(`${path.sep}sessions${path.sep}`) ? 2 : 0;
    const plain = candidate.file.endsWith('.zst') ? 0 : 1;
    const prior = selected.get(base);
    if (!prior || active + plain > prior.priority) selected.set(base, { ...candidate, priority: active + plain });
  }
  return [...selected.values()].map(candidate => ({
    id: `codex:${digest(candidate.file)}`,
    source: 'codex', version: 1, bytes: candidate.size, sessionCount: 1,
    file: candidate.file, isZstd: candidate.file.endsWith('.zst'),
  }));
}

async function discoverClaude(root) {
  const files = [];
  await walkJsonl(root, files);
  return files.map(candidate => ({
    id: `claude:${digest(candidate.file)}`,
    source: 'claude', version: 1, bytes: candidate.size, sessionCount: 1,
    file: candidate.file, isZstd: false,
  }));
}

function workbuddyInventory(dbPath) {
  if (!existsSync(dbPath)) return { available: false, sessions: 0, readable: false };
  let database;
  try {
    database = new DatabaseSync(dbPath, { readOnly: true });
    const sessions = Number(database.prepare('SELECT COUNT(*) AS count FROM sessions').get()?.count) || 0;
    // Current Workbuddy schema stores session metadata/usage locally but not transcript messages.
    const tables = new Set(database.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all().map(row => row.name));
    const readable = ['messages', 'session_messages', 'conversation_messages', 'chat_messages']
      .some(name => tables.has(name));
    return { available: true, sessions, readable };
  } catch {
    return { available: false, sessions: 0, readable: false };
  } finally {
    database?.close();
  }
}

async function isWorkbuddyTranscriptFile(file) {
  let handle;
  try {
    handle = await open(file);
    const buffer = Buffer.alloc(64 * 1024);
    const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
    for (const line of buffer.toString('utf8', 0, bytesRead).split(/\r?\n/)) {
      try {
        const row = JSON.parse(line);
        if (row && typeof row === 'object' && typeof row.sessionId === 'string'
          && ['user', 'assistant'].includes(row.role) && Array.isArray(row.content)) return true;
      } catch {}
    }
  } catch {} finally {
    await handle?.close().catch(() => {});
  }
  return false;
}

async function discoverWorkbuddy(directories) {
  const candidates = [];
  const roots = await Promise.all(directories.map(directory => realpath(directory).catch(() => null)));
  for (const root of new Set(roots.filter(Boolean))) await walkJsonl(root, candidates);
  const transcripts = [];
  for (const candidate of candidates) {
    if (!await isWorkbuddyTranscriptFile(candidate.file)) continue;
    transcripts.push({
      id: `workbuddy:${digest(candidate.file)}`,
      source: 'workbuddy', version: 1, bytes: candidate.size, sessionCount: 1,
      file: candidate.file, isZstd: false,
    });
  }
  return transcripts;
}

/** Discover local candidates. `file` fields on entries are internal-only and must not be sent to a browser. */
export async function discoverHistory({ codexHome, claudeRoot, workbuddyDb } = {}) {
  const workbuddyRoot = workbuddyDirectory();
  const workbuddy = workbuddyDb || path.join(workbuddyRoot, 'workbuddy.db');
  const codexGroups = await Promise.all(codexHomes(codexHome || undefined).map(discoverCodex));
  const codexEntries = codexGroups.flat();
  const claudeEntries = await discoverClaude(claudeRoot || claudeProjects());
  const wb = workbuddyInventory(workbuddy);
  const workbuddyEntries = await discoverWorkbuddy(workbuddyDb
    ? [path.dirname(workbuddyDb)] : workbuddyTranscriptDirectories(workbuddyRoot));
  const entries = [...codexEntries, ...claudeEntries, ...workbuddyEntries];
  return {
    entries,
    sources: [
      { id: 'codex', name: 'Codex', available: codexEntries.length > 0,
        note: codexEntries.length ? `可读取 ${codexEntries.length} 份本机对话记录` : '未找到本机 Codex 对话记录' },
      { id: 'claude', name: 'Claude Code', available: claudeEntries.length > 0,
        note: claudeEntries.length ? `可读取 ${claudeEntries.length} 份本机对话记录` : '未找到本机 Claude Code 对话记录' },
      { id: 'workbuddy', name: 'Workbuddy', available: workbuddyEntries.length > 0 || wb.available,
        partial: wb.available && workbuddyEntries.length === 0,
        note: workbuddyEntries.length ? `可读取 ${workbuddyEntries.length} 份本机对话记录`
          : !wb.available ? '未找到或无法读取 Workbuddy 数据库'
            : `检测到 ${wb.sessions} 个会话目录；未找到可读取的会话正文，未纳入备份` },
    ],
  };
}

function codexMessage(record, state) {
  const payload = record.payload || {};
  if (record.type === 'session_meta') {
    state.sessionId = typeof payload.id === 'string' ? payload.id : state.sessionId;
    state.project = labelFromPath(payload.cwd || payload.runtime_workspace_roots?.find(value => typeof value === 'string')) || state.project;
    return null;
  }
  const item = record.type === 'response_item' ? payload : record.item;
  if (!item || item.type !== 'message' || !['user', 'assistant'].includes(item.role)) return null;
  const text = textFromContent(item.content);
  return text ? { role: item.role, text, at: record.timestamp || payload.timestamp || null } : null;
}

async function* readCodex(entry, byteLimit) {
  const state = { sessionId: path.basename(entry.file).replace(/\.jsonl(?:\.zst)?$/, ''), project: null };
  for await (const line of linesFromFile(entry.file, entry.isZstd, byteLimit)) {
    if (!line.includes('message') && !line.includes('session_meta')) continue;
    try {
      const message = codexMessage(JSON.parse(line), state);
      if (!message) continue;
      yield { sessionId: state.sessionId, source: 'codex', project: state.project, title: state.project || 'Codex 会话', ...message };
    } catch {}
  }
}

async function* readClaude(entry, byteLimit) {
  const fallback = path.basename(entry.file, '.jsonl');
  for await (const line of linesFromFile(entry.file, false, byteLimit)) {
    if (!line.includes('"user"') && !line.includes('"assistant"')) continue;
    try {
      const event = JSON.parse(line);
      const message = event.message || {};
      if (!['user', 'assistant'].includes(message.role)) continue;
      const text = textFromContent(message.content);
      if (!text) continue;
      const project = labelFromPath(event.cwd);
      yield { sessionId: event.sessionId || fallback, source: 'claude', project,
        title: project || 'Claude Code 会话', role: message.role, text, at: event.timestamp || null };
    } catch {}
  }
}

async function* readWorkbuddy(entry, byteLimit) {
  const fallback = path.basename(entry.file, '.jsonl');
  for await (const line of linesFromFile(entry.file, false, byteLimit)) {
    try {
      const row = JSON.parse(line);
      if (!['user', 'assistant'].includes(row.role)) continue;
      const text = textFromContent(row.content);
      if (!text) continue;
      const project = labelFromPath(row.cwd);
      yield { sessionId: row.sessionId || fallback, source: 'workbuddy', project,
        title: project || 'Workbuddy 会话', role: row.role, text, at: row.timestamp || null };
    } catch {}
  }
}

/** Read a discovered entry as portable user/assistant text. Tool traces and binary payloads are excluded. */
export async function* readHistory(entry, { byteLimit } = {}) {
  if (!entry || typeof entry !== 'object') throw new TypeError('A discovered history entry is required');
  if (entry.source === 'codex') yield* readCodex(entry, byteLimit);
  else if (entry.source === 'claude') yield* readClaude(entry, byteLimit);
  else if (entry.source === 'workbuddy') yield* readWorkbuddy(entry, byteLimit);
  else throw new Error(`Unsupported history source: ${entry.source}`);
}
