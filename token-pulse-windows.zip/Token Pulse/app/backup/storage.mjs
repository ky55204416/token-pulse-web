import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { constants, createWriteStream } from 'node:fs';
import { copyFile, link, lstat, mkdir, mkdtemp, open, realpath, rm, stat, statfs } from 'node:fs/promises';
import path from 'node:path';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { promisify } from 'node:util';

const run = promisify(execFile);
const extension = '.compute-backup';
const unsupportedLinks = new Set(['ENOTSUP', 'EOPNOTSUPP', 'EPERM', 'EXDEV', 'ENOSYS']);
const reservedWindowsName = /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³]|conin\$|conout\$)$/i;
const windowsFolderPicker = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$dialog = [System.Windows.Forms.FolderBrowserDialog]::new()
try {
  $dialog.Description = '选择智脉备份保存位置'
  if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    [Console]::Write($dialog.SelectedPath)
  }
} finally {
  $dialog.Dispose()
}`;

export class StorageError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export async function chooseBackupDirectory() {
  const windows = process.platform === 'win32';
  if (!windows && process.platform !== 'darwin') throw new StorageError(501, '当前系统无法打开原生目录选择器。');
  try {
    const options = { timeout: 185_000, maxBuffer: 256 * 1024, encoding: 'utf8' };
    const { stdout } = windows
      ? await run(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'), [
        '-NoLogo', '-NoProfile', '-NonInteractive', '-STA',
        '-EncodedCommand', Buffer.from(windowsFolderPicker, 'utf16le').toString('base64'),
      ], { ...options, windowsHide: true })
      : await run('/usr/bin/osascript', [
        '-e', 'with timeout of 180 seconds',
        '-e', 'return POSIX path of (choose folder with prompt "选择智脉备份保存位置")',
        '-e', 'end timeout',
      ], options);
    if (windows && stdout === '') return null;
    const selected = windows ? stdout : stdout.replace(/\n$/, '');
    if (!path.isAbsolute(selected)) throw new Error('No absolute folder path');
    const canonical = await realpath(selected);
    if (!(await stat(canonical)).isDirectory()) throw new Error('Not a directory');
    return canonical;
  } catch (error) {
    if (!windows && /\(-128\)/.test(error.stderr ?? '')) return null;
    throw new StorageError(422, '无法选择这个目录，请重新打开保存位置选择器。');
  }
}

export function avoidWindowsDeviceName(name) {
  if (process.platform !== 'win32') return name;
  const firstPart = name.split('.', 1)[0].trimEnd();
  return reservedWindowsName.test(firstPart) ? '_' + name : name;
}

function backupName(header) {
  let name;
  try {
    if (typeof header !== 'string' || header.length > 4096) throw new Error();
    name = decodeURIComponent(header).normalize('NFC');
  } catch {
    throw new StorageError(400, '备份文件名无效。');
  }
  if (!name.toLowerCase().endsWith(extension) || /[\/\\\x00-\x1f\x7f]/.test(name)) {
    throw new StorageError(400, '请选择一个 .compute-backup 备份文件。');
  }
  const stem = name.slice(0, -extension.length)
    .replace(/[^\p{L}\p{N} _.-]/gu, '_')
    .replace(/^[ .]+|[ .]+$/g, '');
  return avoidWindowsDeviceName((boundedStem(stem, 180) || '导入备份') + extension);
}

function boundedStem(stem, maxBytes) {
  let bounded = '';
  for (const character of stem) {
    if (Buffer.byteLength(bounded + character) > maxBytes) break;
    bounded += character;
  }
  return bounded;
}

async function sameFile(target, size, digest) {
  let file;
  try {
    const info = await lstat(target);
    if (!info.isFile() || info.size !== size) return false;
    file = await open(target, constants.O_RDONLY | constants.O_NOFOLLOW);
    const opened = await file.stat();
    if (!opened.isFile() || opened.dev !== info.dev || opened.ino !== info.ino) return false;
    const hash = createHash('sha256');
    for await (const chunk of file.createReadStream({ autoClose: false })) hash.update(chunk);
    return hash.digest('hex') === digest;
  } catch {
    return false;
  } finally {
    await file?.close();
  }
}

async function publish(temporary, target) {
  try {
    await link(temporary, target);
  } catch (error) {
    if (!unsupportedLinks.has(error.code)) throw error;
    await copyFile(temporary, target, constants.COPYFILE_EXCL);
  }
}

export async function importBackupUpload({ request, folder, inspectBackup, readBackup }) {
  const type = request.headers['content-type'];
  if (typeof type !== 'string' || type.split(';', 1)[0].trim().toLowerCase() !== 'application/octet-stream') {
    throw new StorageError(415, '请从历史与备份窗口选择备份文件。');
  }
  const original = backupName(request.headers['x-backup-name']);
  const lengthHeader = request.headers['content-length'];
  const length = lengthHeader === undefined ? null : Number(lengthHeader);
  if (length !== null && (!Number.isSafeInteger(length) || length <= 0 || !/^\d+$/.test(lengthHeader))) {
    throw new StorageError(400, '备份文件大小无效。');
  }

  let stage;
  try {
    await mkdir(folder, { recursive: true, mode: 0o700 });
    if (!(await lstat(folder)).isDirectory()) throw new StorageError(409, '默认备份位置不是可用目录。');
    const space = await statfs(folder, { bigint: true }).catch(() => null);
    if (length !== null && space && BigInt(length) > space.bavail * space.bsize) {
      throw new StorageError(507, '默认备份位置的剩余空间不足。');
    }

    stage = await mkdtemp(path.join(folder, '.importing-'));
    const temporary = path.join(stage, 'archive');
    const hash = createHash('sha256');
    let bytes = 0;
    const measure = new Transform({
      transform(chunk, _encoding, done) {
        bytes += chunk.length;
        if (length !== null && bytes > length) return done(new StorageError(400, '备份文件的大小不一致。'));
        hash.update(chunk);
        done(null, chunk);
      },
    });
    await pipeline(request, measure, createWriteStream(temporary, { flags: 'wx', mode: 0o600 }));
    if (!bytes || (length !== null && bytes !== length)) throw new StorageError(400, '未收到完整的备份文件。');
    const output = await open(temporary, 'r+');
    try {
      await output.sync();
    } finally {
      await output.close();
    }

    let encrypted;
    try {
      ({ encrypted } = await inspectBackup({ file: temporary }));
      if (encrypted === false) await readBackup({ file: temporary, passphrase: null });
      else if (encrypted !== true) throw new Error('Unknown backup format');
    } catch {
      throw new StorageError(422, '备份格式无法识别，或备份内容不完整。');
    }
    const digest = hash.digest('hex');
    const alternative = boundedStem(original.slice(0, -extension.length), 160)
      + '_导入_' + digest.slice(0, 24) + extension;
    for (const name of [original, alternative]) {
      const target = path.join(folder, name);
      try {
        await publish(temporary, target);
        return { name, info: await lstat(target), encrypted, alreadyPresent: false };
      } catch (error) {
        if (error.code !== 'EEXIST') throw error;
        if (await sameFile(target, bytes, digest)) {
          return { name, info: await lstat(target), encrypted, alreadyPresent: true };
        }
      }
    }
    throw new StorageError(409, '相同名称的备份已存在。可以改名后重新导入。');
  } catch (error) {
    if (error instanceof StorageError) throw error;
    if (error.code === 'ENOSPC') throw new StorageError(507, '默认备份位置的剩余空间不足。');
    if (request.aborted || error.code === 'ERR_STREAM_PREMATURE_CLOSE') {
      throw new StorageError(400, '导入已中断，请重新选择文件。');
    }
    throw new StorageError(422, '无法导入备份，请确认文件可读、默认备份位置可写后重试。');
  } finally {
    if (stage) await rm(stage, { recursive: true, force: true }).catch(() => {});
  }
}
